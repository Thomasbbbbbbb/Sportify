<?php
header('Content-Type: application/json');
$mysqli = new mysqli("localhost", "root", "", "sportify");
if ($mysqli->connect_error) {
    http_response_code(500);
    echo json_encode([]);
    exit;
}

$q = $_GET["q"] ?? '';
if (!$q) {
    echo json_encode([]);
    exit;
}

$q = $mysqli->real_escape_string($q);
$results = [];

// on recherche dans coachs
$coachSql = "
    SELECT c.nom, c.email, c.specialite, c.photo
    FROM coachs c
    WHERE c.nom LIKE '%$q%' OR c.specialite LIKE '%$q%'
";
$res1 = $mysqli->query($coachSql);
while ($row = $res1->fetch_assoc()) {
    $row['type'] = 'coach';
    $results[] = $row;
}

// on recherche dans comptes (nom ou email)
$compteSql = "
    SELECT nom, email, type 
    FROM comptes 
    WHERE nom LIKE '%$q%' AND type IN ('coach', 'admin')
";
$res2 = $mysqli->query($compteSql);
while ($row = $res2->fetch_assoc()) {
    $row['photo'] = "images/default.jpg";
    $row['specialite'] = "Non précisée";
    $row['type'] = 'coach';
    $results[] = $row;
}
$servicesSql = "
    SELECT nom 
    FROM services 
    WHERE nom LIKE '%$q%'
";
$res4 = $mysqli->query($servicesSql);
while ($row = $res4->fetch_assoc()) {
    $results[] = [
        'nom' => $row['nom'],
        'type' => 'activite'  
    ];
}
// on recherche dans salle_sport
$salleSql = "
    SELECT nom_salle AS nom, email, photo, description 
    FROM salle_sport 
    WHERE nom_salle LIKE '%$q%' OR description LIKE '%$q%'
";
$res3 = $mysqli->query($salleSql);
while ($row = $res3->fetch_assoc()) {
    $row['specialite'] = "Salle de sport";
    $row['type'] = 'salle';
    $results[] = $row;
}

echo json_encode($results);
?>