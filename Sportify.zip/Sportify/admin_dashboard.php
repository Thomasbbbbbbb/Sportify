<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: index.html");
    exit;
}
$conn = new mysqli("localhost", "root", "", "sportify");
if ($conn->connect_error) die("Erreur de connexion : " . $conn->connect_error);

// Gestion messages
$msg = $_GET["msg"] ?? null;

// CRUD coachs
if (isset($_GET["delete"])) {
    $conn->query("DELETE FROM coachs WHERE id = " . intval($_GET["delete"]));
    header("Location: admin_dashboard.php?section=coach&msg=" . urlencode("✅ Coach supprimé"));
    exit;
}
if (isset($_POST["modifier_id"])) {
    $stmt = $conn->prepare("UPDATE coachs SET nom=?, specialite=?, email=?, photo=?, cv=?, video=?, disponibilite=? WHERE id=?");
    $stmt->bind_param("sssssssi", $_POST["modifier_nom"], $_POST["modifier_specialite"], $_POST["modifier_email"], $_POST["modifier_photo"], $_POST["modifier_cv"], $_POST["modifier_video"], $_POST["modifier_disponibilite"], $_POST["modifier_id"]);
    $stmt->execute();
    $stmt->close();
    header("Location: admin_dashboard.php?section=coach&msg=" . urlencode("✅ Coach modifié"));
    exit;
}
if (isset($_POST["ajouter"])) {
    $stmt = $conn->prepare("INSERT INTO coachs (nom, specialite, email, photo, cv, video, disponibilite) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssss", $_POST["nom"], $_POST["specialite"], $_POST["email"], $_POST["photo"], $_POST["cv"], $_POST["video"], $_POST["disponibilite"]);
    $stmt->execute();
    $stmt->close();
    header("Location: admin_dashboard.php?section=coach&msg=" . urlencode("✅ Coach ajouté"));
    exit;
}
// CRUD salles
if (isset($_POST["ajouter_salle"])) {
    $stmt = $conn->prepare("INSERT INTO salle_sport (nom_salle, numero, telephone, email, photo, description) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $_POST["nom_salle"], $_POST["numero"], $_POST["telephone"], $_POST["email"], $_POST["photo"], $_POST["description"]);
    $stmt->execute();
    $stmt->close();
    header("Location: admin_dashboard.php?section=salle&msg=" . urlencode("✅ Salle ajoutée"));
    exit;
}
if (isset($_POST["modifier_salle_id"])) {
    $stmt = $conn->prepare("UPDATE salle_sport SET nom_salle=?, numero=?, telephone=?, email=?, photo=?, description=? WHERE id=?");
    $stmt->bind_param("ssssssi", $_POST["modifier_nom_salle"], $_POST["modifier_numero"], $_POST["modifier_telephone"], $_POST["modifier_email"], $_POST["modifier_photo"], $_POST["modifier_description"], $_POST["modifier_salle_id"]);
    $stmt->execute();
    $stmt->close();
    header("Location: admin_dashboard.php?section=salle&msg=" . urlencode("✅ Salle modifiée"));
    exit;
}
// CRUD comptes
if (isset($_POST["ajout_compte"])) {
    $stmt = $conn->prepare("INSERT INTO comptes (nom, email, mot_de_passe, type) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $_POST["nom"], $_POST["email"], $_POST["mot_de_passe"], $_POST["type"]);
    $stmt->execute();
    $stmt->close();
    header("Location: admin_dashboard.php?section=compte&msg=" . urlencode("✅ Compte ajouté"));
    exit;
}
if (isset($_POST["modif_id"])) {
    $stmt = $conn->prepare("UPDATE comptes SET nom=?, email=?, type=? WHERE id=?");
    $stmt->bind_param("sssi", $_POST["modif_nom"], $_POST["modif_email"], $_POST["modif_type"], $_POST["modif_id"]);
    $stmt->execute();
    $stmt->close();
    header("Location: admin_dashboard.php?section=compte&msg=" . urlencode("✅ Compte modifié"));
    exit;
}
if (isset($_GET["delete_compte"])) {
    $conn->query("DELETE FROM comptes WHERE id = " . intval($_GET["delete_compte"]));
    header("Location: admin_dashboard.php?section=compte&msg=" . urlencode("✅ Compte supprimé"));
    exit;
}

// Données
$result = $conn->query("SELECT * FROM coachs");
$sallesResult = $conn->query("SELECT * FROM salle_sport");
$comptesResult = $conn->query("SELECT * FROM comptes");
$coachToEdit = $_GET["edit"] ?? null;
$salleToEdit = $_GET["edit_salle"] ?? null;
$compteToEdit = $_GET["edit_compte"] ?? null;
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      margin: 0;
      font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
      background: #f1f2f6;
      color: #2f3640;
    }
    header {
      background: #2d3436;
      color: white;
      padding: 20px;
      text-align: center;
      font-size: 24px;
      font-weight: bold;
      letter-spacing: 1px;
    }
    .container {
      max-width: 1100px;
      margin: 40px auto;
      padding: 20px;
      background: white;
      border-radius: 12px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.1);
    }
    .nav {
      display: flex;
      gap: 10px;
      margin-bottom: 30px;
    }
    .nav button {
      flex: 1;
      padding: 12px;
      background: #0984e3;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
      transition: background 0.3s ease;
    }
    .nav button:hover {
      background: #74b9ff;
    }
    .logout {
      background: #d63031 !important;
    }
    .section {
      display: none;
      animation: fadeIn 0.4s ease;
    }
    .section.active {
      display: block;
    }
    h2 {
      margin-top: 0;
      margin-bottom: 20px;
      font-size: 22px;
      color: #2d3436;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
   .cv-popup {
  position: fixed;
  top: 20px;
  left: 50%;
  transform: translateX(-50%);
  background-color: #e6ffed;
  color: #155724;
  padding: 20px;
  border: 2px solid #28a745;
  border-radius: 10px;
  z-index: 9999;
  box-shadow: 0 0 15px rgba(0,0,0,0.2);
  max-width: 400px;
  animation: slideDown 0.4s ease-out;
}
.cv-popup .close-btn {
  position: absolute;
  top: 5px;
  right: 15px;
  font-size: 18px;
  font-weight: bold;
  cursor: pointer;
}
.cv-popup .progress-bar {
  position: absolute;
  bottom: 0;
  left: 0;
  height: 4px;
  background-color: #28a745;
  width: 100%;
  animation: shrink 5s linear forwards;
}
@keyframes slideDown {
  from { opacity: 0; transform: translateY(-20px); }
  to { opacity: 1; transform: translateY(0); }
}
@keyframes fadeOutUp {
  from { opacity: 1; transform: translateY(0); }
  to { opacity: 0; transform: translateY(-20px); }
}
.cv-popup.fade-out {
  animation: fadeOutUp 0.5s ease-in-out forwards;
}
@keyframes shrink {
  from { width: 100%; }
  to { width: 0%; }
}
form {
  background: #f7f9fa;
  padding: 20px;
  border-radius: 10px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.05);
  margin-top: 20px;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

form input[type="text"],
form input[type="email"],
form input[type="password"],
form select,
form textarea {
  padding: 10px 12px;
  border: 1px solid #ccc;
  border-radius: 6px;
  font-size: 15px;
  width: 100%;
  transition: border-color 0.3s ease, box-shadow 0.3s ease;
}

form input:focus,
form select:focus,
form textarea:focus {
  border-color: #0984e3;
  box-shadow: 0 0 0 2px rgba(9,132,227,0.2);
  outline: none;
}

form button[type="submit"] {
  align-self: flex-start;
  background: #00b894;
  color: white;
  padding: 10px 18px;
  font-weight: bold;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: background 0.3s ease;
}

form button[type="submit"]:hover {
  background: #019874;
}

  </style>
</head>
<body>
  <header>
    🎛️ Tableau de bord Administrateur
  </header>
  <div class="container">
    <div id="popupMsg" class="cv-popup" style="display:none;">
      <span class="close-btn" onclick="document.getElementById('popupMsg').style.display='none';">&times;</span>
      <div id="popupMsgContent"></div>
     <div class="progress-bar"></div>
    </div>
    <div class="nav">
      <button onclick="showSection('sectionCoach')">👥 Coachs</button>
      <button onclick="showSection('sectionSalle')">🏢 Salles</button>
      <button onclick="showSection('sectionComptes')">🔐 Comptes</button>
      <button id="logoutBtn" class="logout">🚪 Déconnexion</button>
    </div>
    <div id="popup" style="display:none; background:#dff9fb; border-left: 6px solid #00cec9; padding: 15px; margin-bottom: 20px; border-radius: 8px;"></div>

    <div id="sectionCoach" class="section">
      <h2>👥 Gestion des coachs</h2>
      <table style="width:100%; border-collapse:collapse;">
        <tr style="background:#dfe6e9;">
          <th>Nom</th><th>Spécialité</th><th>Email</th><th>Photo</th><th>CV</th><th>Vidéo</th><th>Dispo</th><th>Actions</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()): ?>
          <?php if ($coachToEdit == $row['id']): ?>
            <tr><form method="post">
              <td><input type="text" name="modifier_nom" value="<?= $row['nom'] ?>"></td>
              <td><input type="text" name="modifier_specialite" value="<?= $row['specialite'] ?>"></td>
              <td><input type="email" name="modifier_email" value="<?= $row['email'] ?>"></td>
              <td><input type="text" name="modifier_photo" value="<?= $row['photo'] ?>"></td>
              <td><input type="text" name="modifier_cv" value="<?= $row['cv'] ?>"></td>
              <td><input type="text" name="modifier_video" value="<?= $row['video'] ?>"></td>
              <td><textarea name="modifier_disponibilite"><?= $row['disponibilite'] ?></textarea></td>
              <td>
                <input type="hidden" name="modifier_id" value="<?= $row['id'] ?>">
                <button type="submit">💾</button>
                <a href="admin_dashboard.php?section=coach">❌</a>
              </td>
            </form></tr>
          <?php else: ?>
            <tr>
              <td><?= htmlspecialchars($row['nom']) ?></td>
              <td><?= htmlspecialchars($row['specialite']) ?></td>
              <td><?= htmlspecialchars($row['email']) ?></td>
              <td><img src="<?= $row['photo'] ?>" width="50"></td>
              <td><?= $row['cv'] ? "<a href='voir_cv.php?file=" . urlencode(basename($row['cv'])) . "'>📄</a>" : "—" ?></td>
              <td><?= $row['video'] ? "<a href='{$row['video']}' target='_blank'>▶️</a>" : "—" ?></td>
              <td><pre><?= $row['disponibilite'] ?></pre></td>
              <td>
                <a href="?edit=<?= $row['id'] ?>&section=coach">✏️</a>
                <a href="?delete=<?= $row['id'] ?>&section=coach" onclick="return confirm('Supprimer ?')">🗑️</a>
              </td>
            </tr>
          <?php endif; ?>
        <?php endwhile; ?>
      </table>

      <h3>➕ Ajouter un coach</h3>
      <form method="post">
        <input type="hidden" name="ajouter" value="1">
        <input type="text" name="nom" placeholder="Nom" required>
        <input type="text" name="specialite" placeholder="Spécialité" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="text" name="photo" placeholder="Lien photo">
        <input type="text" name="cv" placeholder="Lien fichier CV">
        <input type="text" name="video" placeholder="Lien vidéo">
        <textarea name="disponibilite" placeholder="Disponibilité"></textarea>
        <button type="submit">Ajouter</button>
      </form>
      <h3>📝 Générer un CV (XML)</h3>
      <form id="cvForm" style="margin-bottom: 40px;">
  	<input type="text" name="nom_complet" placeholder="Nom complet" required>
  	<input type="text" name="specialite" placeholder="Spécialité" required>
  	<textarea name="formations" placeholder="Formations (une par ligne)" rows="3" required></textarea>
  	<textarea name="experiences" placeholder="Expériences (une par ligne)" rows="3" required></textarea>
  	<button type="submit" style="margin-top:10px;">Générer le fichier XML</button>
      </form>
    </div>
    <div id="sectionSalle" class="section">
      <h2>🏢 Salles de sport</h2>
      <table>
        <tr style="background:#dfe6e9;">
          <th>Nom</th><th>Numéro</th><th>Téléphone</th><th>Email</th><th>Photo</th><th>Description</th><th>Actions</th>
        </tr>
        <?php while ($salle = $sallesResult->fetch_assoc()): ?>
          <?php if ($salleToEdit == $salle['id']): ?>
            <tr><form method="post">
              <td><input type="text" name="modifier_nom_salle" value="<?= $salle['nom_salle'] ?>"></td>
              <td><input type="text" name="modifier_numero" value="<?= $salle['numero'] ?>"></td>
              <td><input type="text" name="modifier_telephone" value="<?= $salle['telephone'] ?>"></td>
              <td><input type="email" name="modifier_email" value="<?= $salle['email'] ?>"></td>
              <td><input type="text" name="modifier_photo" value="<?= $salle['photo'] ?>"></td>
              <td><textarea name="modifier_description"><?= $salle['description'] ?></textarea></td>
              <td>
                <input type="hidden" name="modifier_salle_id" value="<?= $salle['id'] ?>">
                <button type="submit">💾</button>
                <a href="admin_dashboard.php?section=salle">❌</a>
              </td>
            </form></tr>
          <?php else: ?>
            <tr>
              <td><?= htmlspecialchars($salle['nom_salle']) ?></td>
              <td><?= htmlspecialchars($salle['numero']) ?></td>
              <td><?= htmlspecialchars($salle['telephone']) ?></td>
              <td><?= htmlspecialchars($salle['email']) ?></td>
              <td><img src="<?= $salle['photo'] ?>" width="50"></td>
              <td><pre><?= $salle['description'] ?></pre></td>
              <td><a href="?edit_salle=<?= $salle['id'] ?>&section=salle">✏️</a></td>
            </tr>
          <?php endif; ?>
        <?php endwhile; ?>
      </table>

      <h3>➕ Ajouter une salle</h3>
      <form method="post">
        <input type="hidden" name="ajouter_salle" value="1">
        <input type="text" name="nom_salle" placeholder="Nom" required>
        <input type="text" name="numero" placeholder="Numéro" required>
        <input type="text" name="telephone" placeholder="Téléphone" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="text" name="photo" placeholder="Lien photo">
        <textarea name="description" placeholder="Description..."></textarea>
        <button type="submit">Ajouter</button>
      </form>
    </div>

    <div id="sectionComptes" class="section">
      <h2>🔐 Comptes utilisateurs</h2>
      <table>
        <tr style="background:#dfe6e9;">
          <th>Nom</th><th>Email</th><th>Type</th><th>Actions</th>
        </tr>
        <?php while ($user = $comptesResult->fetch_assoc()): ?>
          <?php if ($compteToEdit == $user["id"]): ?>
            <tr><form method="post">
              <td><input type="text" name="modif_nom" value="<?= $user['nom'] ?>"></td>
              <td><input type="email" name="modif_email" value="<?= $user['email'] ?>"></td>
              <td>
                <select name="modif_type">
                  <option value="admin" <?= $user['type'] === 'admin' ? 'selected' : '' ?>>admin</option>
                  <option value="coach" <?= $user['type'] === 'coach' ? 'selected' : '' ?>>coach</option>
                  <option value="client" <?= $user['type'] === 'client' ? 'selected' : '' ?>>client</option>
                </select>
              </td>
              <td>
                <input type="hidden" name="modif_id" value="<?= $user['id'] ?>">
                <button type="submit">💾</button>
                <a href="admin_dashboard.php?section=compte">❌</a>
              </td>
            </form></tr>
          <?php else: ?>
            <tr>
              <td><?= htmlspecialchars($user['nom']) ?></td>
              <td><?= htmlspecialchars($user['email']) ?></td>
              <td><?= htmlspecialchars($user['type']) ?></td>
              <td>
                <a href="?edit_compte=<?= $user['id'] ?>&section=compte">✏️</a>
                <a href="?delete_compte=<?= $user['id'] ?>&section=compte" onclick="return confirm('Supprimer ce compte ?')">🗑️</a>
              </td>
            </tr>
          <?php endif; ?>
        <?php endwhile; ?>
      </table>

      <h3>➕ Ajouter un compte</h3>
      <form method="post">
        <input type="hidden" name="ajout_compte" value="1">
        <input type="text" name="nom" placeholder="Nom" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="mot_de_passe" placeholder="Mot de passe" required>
        <select name="type" required>
          <option value="admin">Admin</option>
          <option value="coach">Coach</option>
          <option value="client">Client</option>
        </select>
        <button type="submit">Créer</button>
      </form>
    </div>
<script>
function showSection(id) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

// Charger la bonne section à l'ouverture
document.addEventListener("DOMContentLoaded", () => {
  const params = new URLSearchParams(window.location.search);
  const section = params.get("section");
  if (section === "coach") showSection("sectionCoach");
  else if (section === "salle") showSection("sectionSalle");
  else if (section === "compte") showSection("sectionComptes");

  const msg = params.get("msg");
if (msg) {
  const popup = document.getElementById("popupMsg");
  const content = document.getElementById("popupMsgContent");
  popup.classList.remove("fade-out");
  content.innerText = decodeURIComponent(msg);
  popup.style.display = "block";
  popup.querySelector(".progress-bar").style.animation = "shrink 5s linear forwards";
  setTimeout(() => {
    popup.classList.add("fade-out");
    setTimeout(() => {
      popup.style.display = "none";
      popup.classList.remove("fade-out");
    }, 500);
  }, 5000);
}

});

// Déconnexion animée
document.getElementById("logoutBtn")?.addEventListener("click", function (e) {
  e.preventDefault();
  const btn = this;
  const text = "Déconnexion...";
  btn.disabled = true;
  btn.innerText = "";
  let i = 0;
  const anim = setInterval(() => {
    btn.innerText += text[i++];
    if (i === text.length) {
      clearInterval(anim);
      setTimeout(() => { window.location.href = "logout.php"; }, 500);
    }
  }, 50);
});
document.getElementById("cvForm")?.addEventListener("submit", function(e) {
  e.preventDefault();
  const formData = new FormData(this);
  fetch("generer_cv.php", {
    method: "POST",
    body: formData
  })
  .then(res => res.json())
  .then(data => {
    const popup = document.getElementById("popupMsg");
    const content = document.getElementById("popupMsgContent");
    popup.classList.remove("fade-out");
    if (data.success) {
      content.innerHTML = `✅ CV généré : <a href="${data.lien}" target="_blank">${data.fichier}</a><br><small>À utiliser dans le champ CV : <code>${data.chemin}</code></small>`;
    } else {
      content.innerHTML = `❌ Erreur : ${data.message}`;
    }
    popup.style.display = "block";
    const bar = popup.querySelector(".progress-bar");
    bar.style.animation = "none";
    void bar.offsetWidth;
    bar.style.animation = "shrink 5s linear forwards";
    setTimeout(() => {
      popup.classList.add("fade-out");
      setTimeout(() => {
        popup.style.display = "none";
        popup.classList.remove("fade-out");
      }, 500);
    }, 5000);
  })
  .catch(() => {
    const popup = document.getElementById("popupMsg");
    popup.style.display = "block";
    document.getElementById("popupMsgContent").innerText = "❌ Erreur serveur.";
  });
});

</script>
</body>
</html>
