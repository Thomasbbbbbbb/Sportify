<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: index.html");
    exit;
}

$conn = new mysqli("localhost", "root", "", "sportify");
if ($conn->connect_error) die("Erreur de connexion : " . $conn->connect_error);

// Récupérer les infos client
$email = $_SESSION["email"];
$client = $conn->query("SELECT * FROM comptes WHERE email='$email' AND type='client'")->fetch_assoc();

// Mettre à jour les RDV passés
$conn->query("UPDATE rdv SET statut='passé' WHERE date < NOW() AND statut='à venir'");

// Modifier les infos
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["modif_client"])) {
    $nom = $conn->real_escape_string($_POST["nom"]);
    $emailNouveau = $conn->real_escape_string($_POST["email"]);
    $adresse = $conn->real_escape_string($_POST["adresse"]);
    $carte = $conn->real_escape_string($_POST["carte_etudiante"]);

    $stmt = $conn->prepare("UPDATE comptes SET nom=?, email=?, adresse=?, carte_etudiante=? WHERE id=?");
    $stmt->bind_param("ssssi", $nom, $emailNouveau, $adresse, $carte, $client["id"]);
    $stmt->execute();
    $_SESSION["email"] = $emailNouveau;
    header("Location: client_dashboard.php?msg=" . urlencode("✅ Informations mises à jour"));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['payer_service'])) {
    $id_rdv = (int) $_POST['id_rdv'];
    $moyen = $conn->real_escape_string($_POST['moyen']);
    $montant = (float) $_POST['montant'];

    $numero = $conn->real_escape_string($_POST['numero']);
    $nom_carte = $conn->real_escape_string($_POST['nom_carte']);
    $expiration = $conn->real_escape_string($_POST['expiration']);
    $cvv = $conn->real_escape_string($_POST['cvv']);

    // Vérification carte
    $carte_ok = $conn->query("SELECT * FROM cartes_bancaires WHERE numero='$numero' AND nom='$nom_carte' AND expiration='$expiration' AND cvv='$cvv' AND moyen='$moyen'");

    if (!$carte_ok || $carte_ok->num_rows === 0) {
    header("Location: client_dashboard.php?msg=" . urlencode("❌ Paiement refusé : carte invalide ou non enregistrée"));
    exit;
}


    // Éviter doublons
    $check = $conn->query("SELECT * FROM paiements WHERE id_rdv=$id_rdv AND id_client={$client['id']}");
    if ($check->num_rows === 0) {
        $conn->query("INSERT INTO paiements (id_client, id_rdv, montant, moyen, statut, date) VALUES ({$client['id']}, $id_rdv, $montant, '$moyen', 'validé', NOW())");

        // Récup infos service
        $infos = $conn->query("SELECT s.nom AS service_nom, s.description, s.prix, r.date, r.lieu
                               FROM rdv r JOIN services s ON r.id_service = s.id 
                               WHERE r.id = $id_rdv")->fetch_assoc();

        $service = $infos['service_nom'] ?? "Service inconnu";
        $desc = $infos['description'] ?? "Aucune description";
        $prix = number_format($infos['prix'], 2);
        $date = date("d/m/Y H:i", strtotime($infos['date']));
        $lieu = $infos['lieu'];

        $message = <<<MSG
✅ Paiement confirmé pour le service **"$service"** :\n
📅 Date : $date  
📍 Lieu : $lieu  
💳 Moyen : $moyen  
💰 Montant : $prix €  
📝 Description : $desc
Merci pour votre confiance !
MSG;

        $system = "system@site.com";
        $stmt = $conn->prepare("INSERT INTO messages (sender_email, receiver_email, contenu) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $system, $email, $message);
        $stmt->execute();

        header("Location: client_dashboard.php?msg=" . urlencode("✅ Paiement validé"));
        exit;
    }
}


// Annuler un RDV
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["annuler_rdv"])) {
    $idRdv = (int) $_POST["annuler_rdv"];
    $stmt = $conn->prepare("UPDATE rdv SET statut='annulé' WHERE id=? AND id_client=?");
    $stmt->bind_param("ii", $idRdv, $client["id"]);
    $stmt->execute();
    header("Location: client_dashboard.php?msg=" . urlencode("❌ Rendez-vous annulé"));
    exit;
}

// Récupérer les RDV avec coach OU admin
$rdv = $conn->query("SELECT r.*, c.nom AS coach_nom 
                     FROM rdv r
                     JOIN comptes c ON r.id_coach = c.id
                     WHERE r.id_client = {$client['id']} AND c.type IN ('coach', 'admin')
                     ORDER BY r.date DESC")->fetch_all(MYSQLI_ASSOC);

$msg = $_GET["msg"] ?? null;
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Client</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      margin: 0;
      background: #ecf0f1;
      color: #2c3e50;
    }
    header {
      background: #2c3e50;
      color: white;
      padding: 20px;
      font-size: 24px;
      text-align: center;
    }
    .container {
      max-width: 800px;
      margin: 30px auto;
      background: white;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.1);
      animation: fadeIn 0.4s ease-in-out;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .actions {
      display: flex;
      justify-content: space-between;
      margin-top: 20px;
      flex-wrap: wrap;
      gap: 10px;
    }
    .actions button, .btn {
      background: #3498db;
      color: white;
      padding: 10px 18px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s ease;
      text-decoration: none;
    }
    .actions button:hover, .btn:hover {
      background: #2980b9;
    }
    .cancel-btn {
      background: #e74c3c;
      border: none;
      color: white;
      padding: 6px 12px;
      border-radius: 6px;
      cursor: pointer;
      transition: background 0.3s ease;
    }
    .cancel-btn:hover {
      background: #c0392b;
    }
    .edit-form input {
      display: block;
      width: 100%;
      margin: 10px 0;
      padding: 10px;
      border-radius: 6px;
      border: 1px solid #ccc;
    }
    .popup {
      position: fixed;
      top: 20px;
      left: 50%;
      transform: translateX(-50%);
      background: #e0ffe0;
      color: #2d862d;
      padding: 15px 20px;
      border: 2px solid #2ecc71;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.2);
      display: none;
      z-index: 1000;
    }
    .popup .bar {
      height: 4px;
      background: #2ecc71;
      animation: progress 5s linear forwards;
    }
    @keyframes progress {
      from { width: 100%; }
      to { width: 0%; }
    }
    #logoutBtn {
      background: #e74c3c;
    }
    #logoutBtn:hover {
      background: #c0392b;
    }
    ::-webkit-scrollbar {
      width: 6px;
    }
    ::-webkit-scrollbar-thumb {
      background: #ccc;
      border-radius: 3px;
    }
.modal {
  display: none; position: fixed; z-index: 9999;
  left: 0; top: 0; width: 100%; height: 100%;
  background-color: rgba(0,0,0,0.6);
}
.modal-content {
  background: #fff; margin: 10% auto; padding: 20px;
  max-width: 500px; border-radius: 10px;
  box-shadow: 0 5px 15px rgba(0,0,0,0.3);
}
.modal-content input, .modal-content select {
  width: 100%; margin: 10px 0; padding: 10px;
  border: 1px solid #ccc; border-radius: 6px;
}
.modal-content button {
  background: #27ae60; color: white;
  padding: 10px 16px; border: none;
  border-radius: 6px; cursor: pointer;
}
.modal-content .close {
  float: right; font-size: 22px;
  font-weight: bold; cursor: pointer;
}
  </style>
</head>
<body>
  <header>🎯 Tableau de bord Client</header>
  <div class="container">
    <h2>👤 Mes Informations</h2>
    <div id="clientInfo">
      <p><strong>Nom :</strong> <?= htmlspecialchars($client["nom"]) ?></p>
      <p><strong>Email :</strong> <?= htmlspecialchars($client["email"]) ?></p>
      <p><strong>Adresse :</strong> <?= isset($client["adresse"]) && $client["adresse"] !== null ? htmlspecialchars($client["adresse"]) : "Non renseignée" ?></p>
      <p><strong>Carte Étudiante :</strong> <?= isset($client["carte_etudiante"]) && $client["carte_etudiante"] !== null ? htmlspecialchars($client["carte_etudiante"]) : "Non renseignée" ?></p>
      <p><strong>Informations de paiement :</strong> 🔒 <em>confidentielles</em></p>
      <div class="actions">
        <button onclick="document.getElementById('editForm').style.display='block'">✏️ Modifier</button>
        <a href="chatroom.php" class="btn">💬 Messagerie</a>
        <button class="btn" type="button" onclick="togglePaiement()">💳 Gérer mes paiements</button>
  <a href="index.html" class="btn">⬅️ Retour à l'accueil</a>
        <button id="logoutBtn">🚪 Se déconnecter</button>
      </div>
    </div>
    <div id="paiementSection" style="display:none; margin-top: 30px;">
  <h2>💳 Paiements</h2>
  <div style="max-height: 400px; overflow-y: auto; padding-right: 10px;">
    <ul style="list-style: none; padding: 0;">
      <?php
      $rdv_paiements = $conn->query("SELECT r.id, r.date, s.nom AS service_nom, s.prix,
        (SELECT statut FROM paiements WHERE id_client = {$client['id']} AND id_rdv = r.id LIMIT 1) AS paiement_statut
        FROM rdv r
        JOIN services s ON r.id_service = s.id
        WHERE r.id_client = {$client['id']} ORDER BY r.date DESC");
      while ($p = $rdv_paiements->fetch_assoc()): ?>
        <li style="margin-bottom: 15px; padding: 15px; background: #fff; border-left: 6px solid #3498db; border-radius: 8px; box-shadow: 0 0 8px rgba(0,0,0,0.05);">
          <strong><?= date('d/m/Y H:i', strtotime($p['date'])) ?></strong><br>
          Service : <?= htmlspecialchars($p['service_nom']) ?> — Prix : <?= number_format($p['prix'], 2) ?> €<br>
          Paiement :
          <?= $p['paiement_statut'] === 'validé'
                ? '<span style="color:green;font-weight:bold;">✅ Payé</span>'
                : '<span style="color:red;">En attente</span>' ?>
          <?php if ($p['paiement_statut'] !== 'validé'): ?>
            <form method="post" style="margin-top:10px;">
              <input type="hidden" name="payer_service" value="1">
              <input type="hidden" name="id_rdv" value="<?= $p['id'] ?>">
              <input type="hidden" name="montant" value="<?= $p['prix'] ?>">
             
              <button type="button" class="btn" onclick="openPaymentPopup(<?= $p['id'] ?>, <?= $p['prix'] ?>)">💳 Payer</button>
            </form>
          <?php endif; ?>
        </li>
      <?php endwhile; ?>
    </ul>
  </div>
</div>

    <form method="post" class="edit-form" id="editForm" style="display:none;">
      <input type="hidden" name="modif_client" value="1">
      <input type="text" name="nom" value="<?= htmlspecialchars($client["nom"]) ?>" required>
      <input type="email" name="email" value="<?= htmlspecialchars($client["email"]) ?>" required>
      <input type="text" name="adresse" value="<?= isset($client["adresse"]) ? htmlspecialchars($client["adresse"]) : "" ?>">
      <input type="text" name="carte_etudiante" value="<?= isset($client["carte_etudiante"]) ? htmlspecialchars($client["carte_etudiante"]) : "" ?>">
      <div class="actions">
        <button type="submit">💾 Sauvegarder</button>
        <button type="button" onclick="document.getElementById('editForm').style.display='none'">❌ Annuler</button>
      </div>
    </form>

    <h2 style="margin-top: 40px;">🗓️ Tous mes Rendez-vous</h2>
    <div style="max-height: 400px; overflow-y: auto; padding-right: 10px;">
      <ul style="list-style: none; padding: 0;">
        <?php foreach ($rdv as $r): ?>
          <?php
            $color = match($r['statut']) {
              'à venir' => '#2ecc71',
              'annulé' => '#e74c3c',
              'passé'  => '#bdc3c7',
              default => '#95a5a6'
            };
          ?>
          <li style="margin-bottom: 15px; padding: 15px; background: #fff; border-left: 6px solid <?= $color ?>; border-radius: 8px; box-shadow: 0 0 8px rgba(0,0,0,0.05);">
            <strong><?= date('d/m/Y H:i', strtotime($r['date'])) ?></strong> — <span style="color: <?= $color ?>; text-transform: uppercase; font-weight: bold;"><?= $r['statut'] ?></span><br>
            Coach : <?= htmlspecialchars($r['coach_nom']) ?><br>
            Service : <?= htmlspecialchars($r['id_service']) ?><br>
            Lieu : <?= htmlspecialchars($r['lieu']) ?>
            <?php if ($r['statut'] === 'à venir'): ?>
              <form method="post" style="margin-top: 10px;">
                <input type="hidden" name="annuler_rdv" value="<?= $r['id'] ?>">
                <button type="submit" class="cancel-btn">🗑️ Annuler</button>
              </form>
            <?php endif; ?>
          </li>
        <?php endforeach; ?>
        <?php if (empty($rdv)): ?>
          <p>Aucun rendez-vous pour le moment.</p>
        <?php endif; ?>
      </ul>
    </div>
  </div>

  <div class="popup" id="popup"><?= $msg ? "<div>$msg</div><div class='bar'></div>" : "" ?></div>
<!-- === POPUP DE PAIEMENT === -->
<div id="paymentModal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="closeModal()">&times;</span>

    <!-- Étape 1 : Coordonnées client -->
    <div id="step1">
      <h3>🧾 Informations personnelles</h3>
      <form id="step1Form">
        <input type="text" name="nom" placeholder="Nom & Prénom" required>
        <input type="text" name="adresse1" placeholder="Adresse Ligne 1" required>
        <input type="text" name="adresse2" placeholder="Adresse Ligne 2">
        <input type="text" name="ville" placeholder="Ville" required>
        <input type="text" name="code_postal" placeholder="Code Postal" required>
        <input type="text" name="pays" placeholder="Pays" required>
        <input type="tel" name="tel" placeholder="Numéro de téléphone" required>
        <input type="text" name="carte_etudiante" placeholder="Carte Étudiant" required>
        <button type="button" onclick="nextStep()">Continuer ➡️</button>
      </form>
    </div>

    <!-- Étape 2 : Données bancaires -->
    <div id="step2" style="display:none;">
      <h3>💳 Paiement</h3>
      <form id="step2Form" method="post">
        <input type="hidden" name="payer_service" value="1">
        <input type="hidden" name="id_rdv" id="hiddenIdRdv">
        <input type="hidden" name="montant" id="hiddenMontant">
        <label>Moyen de paiement :</label>
        <select name="moyen" required>
          <option value="">Sélectionner</option>
          <option value="Visa">Visa</option>
          <option value="MasterCard">MasterCard</option>
          <option value="American Express">American Express</option>
          <option value="PayPal">PayPal</option>
        </select>
        <input type="text" name="numero" placeholder="Numéro de carte" required>
        <input type="text" name="nom_carte" placeholder="Nom sur la carte" required>
        <input type="text" name="expiration" placeholder="Date d’expiration (MM/AA)" required>
        <input type="text" name="cvv" placeholder="Code de sécurité" required>
        <button type="submit">✅ Valider le paiement</button>
      </form>
    </div>
  </div>
</div>
  <script>
    const popup = document.getElementById("popup");
    if (popup.innerText.trim() !== "") {
      popup.style.display = "block";
      setTimeout(() => popup.style.display = "none", 5000);
    }

    const logoutBtn = document.getElementById("logoutBtn");
    if (logoutBtn) {
      logoutBtn.addEventListener("click", () => {
        const animText = "Déconnexion...";
        logoutBtn.disabled = true;
        logoutBtn.innerText = "";
        let i = 0;
        const interval = setInterval(() => {
          logoutBtn.innerText += animText[i++];
          if (i === animText.length) {
            clearInterval(interval);
            setTimeout(() => {
              window.location.href = "logout.php";
            }, 500);
          }
        }, 50);
      });
    }

function togglePaiement() {
  const section = document.getElementById("paiementSection");
  section.style.display = section.style.display === "none" ? "block" : "none";
}
function openPaymentPopup(idRdv, montant) {
  document.getElementById("paymentModal").style.display = "block";
  document.getElementById("hiddenIdRdv").value = idRdv;
  document.getElementById("hiddenMontant").value = montant;
}
function closeModal() {
  document.getElementById("paymentModal").style.display = "none";
  document.getElementById("step1").style.display = "block";
  document.getElementById("step2").style.display = "none";
}
function nextStep() {
  const form = document.getElementById("step1Form");
  if (form.checkValidity()) {
    document.getElementById("step1").style.display = "none";
    document.getElementById("step2").style.display = "block";
  } else {
    form.reportValidity();
  }
}
window.onclick = function(event) {
  if (event.target == document.getElementById("paymentModal")) {
    closeModal();
  }
}
  </script>
</body>
</html>