<?php
// Activer les erreurs visibles en dev
ini_set('display_errors', 1);
error_reporting(E_ALL);
header('Content-Type: application/json');

// Vérifie méthode POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["success" => false, "message" => "Méthode non autorisée."]);
    exit;
}

// Récupération des données
$nom_complet = $_POST["nom_complet"] ?? null;
$specialite = $_POST["specialite"] ?? null;
$formations = $_POST["formations"] ?? null;
$experiences = $_POST["experiences"] ?? null;

// Validation de base
if (!$nom_complet || !$specialite || !$formations || !$experiences) {
    echo json_encode(["success" => false, "message" => "Tous les champs sont requis."]);
    exit;
}

// Traitement
$formationsList = explode("\n", trim($formations));
$experiencesList = explode("\n", trim($experiences));

// Séparer prénom/nom
$parts = explode(" ", trim($nom_complet), 2);
$prenom = isset($parts[0]) ? strtolower($parts[0]) : "inconnu";
$nom = isset($parts[1]) ? strtolower(str_replace(" ", "_", $parts[1])) : "inconnu";

// Génération du fichier
$xml = new SimpleXMLElement("<cv></cv>");
$xml->addChild("nom", $nom_complet);
$xml->addChild("specialite", $specialite);

$formationsNode = $xml->addChild("formations");
foreach ($formationsList as $f) {
    if (trim($f) !== "") {
        $formationsNode->addChild("formation", trim($f));
    }
}

$experiencesNode = $xml->addChild("experiences");
foreach ($experiencesList as $e) {
    if (trim($e) !== "") {
        $experiencesNode->addChild("experience", trim($e));
    }
}

// Sauvegarde
$filename = $prenom . "_" . $nom . "_cv.xml";
$savePath = "cv/" . $filename;

if (!is_dir("cv")) {
    mkdir("cv", 0777, true);
}

$success = $xml->asXML($savePath);
if (!$success) {
    echo json_encode(["success" => false, "message" => "Erreur lors de la sauvegarde du fichier."]);
    exit;
}

// ✅ Réponse JSON vers le JS
echo json_encode([
    "success" => true,
    "fichier" => $filename,
    "chemin" => $savePath,
    "lien" => $savePath
]);
