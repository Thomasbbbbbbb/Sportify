<?php
header('Content-Type: application/json');

try {
    $conn = new PDO("mysql:host=localhost;dbname=Sportify;charset=utf8", "root", "");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Connexion BDD échouée: " . $e->getMessage()]);
    exit;
}

$nom = trim($_POST['nom'] ?? '');
$email = trim($_POST['email'] ?? '');
$mdp = trim($_POST['mot_de_passe'] ?? '');

if (!$nom || !$email || !$mdp) {
    echo json_encode(["success" => false, "message" => "Tous les champs sont obligatoires."]);
    exit;
}

try {
    $stmt = $conn->prepare("SELECT * FROM comptes WHERE email = ?");
    $stmt->execute([$email]);

    if ($stmt->rowCount() > 0) {
        echo json_encode(["success" => false, "message" => "Cet email est déjà utilisé."]);
        exit;
    }

    // mot de passe en clair (non haché)
    $stmt = $conn->prepare("INSERT INTO comptes (nom, email, mot_de_passe, type) VALUES (?, ?, ?, 'client')");
    $stmt->execute([$nom, $email, $mdp]);

    echo json_encode(["success" => true]);
} catch (Exception $e) {
    echo json_encode(["success" => false, "message" => "Erreur SQL: " . $e->getMessage()]);
}
?>
