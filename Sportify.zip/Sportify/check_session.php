<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION["email"])) {
    echo json_encode(["connecte" => false]);
    exit;
}

$conn = new mysqli("localhost", "root", "", "sportify");
if ($conn->connect_error) {
    echo json_encode(["connecte" => false]);
    exit;
}

$email = $_SESSION["email"];
$res = $conn->query("SELECT type FROM comptes WHERE email = '$email'");
$type = $res->fetch_assoc()["type"] ?? "autre";

echo json_encode([
    "connecte" => true,
    "type" => $type
]);