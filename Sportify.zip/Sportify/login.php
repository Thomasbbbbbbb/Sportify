<?php
session_start();
header('Content-Type: application/json');

// Vérifie que la méthode est POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["success" => false, "message" => "Méthode non autorisée"]);
    exit;
}

// Connexion à la base de données
$conn = new mysqli('localhost', 'root', '', 'sportify'); // remplace si besoin

if ($conn->connect_error) {
    echo json_encode(["success" => false, "message" => "Erreur BDD"]);
    exit;
}

// Récupération des champs et sécurisation
$email = $conn->real_escape_string($_POST['email']);
$mdp = $conn->real_escape_string($_POST['mot_de_passe']);

// Requête de vérification
$sql = "SELECT * FROM comptes WHERE email='$email' AND mot_de_passe='$mdp'";
$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $user = $result->fetch_assoc();
    
    // Enregistrement des infos session
    $_SESSION['email'] = $user['email'];
    $_SESSION['nom'] = $user['nom'];
    $_SESSION['type'] = $user['type']; // admin, coach, client

    // Redirection selon type de compte
    $redirect = "index.html";
    if ($user['type'] === "admin") {
        $redirect = "admin_dashboard.php";
    } elseif ($user['type'] === "coach") {
        $redirect = "coach_dashboard.php";
    } elseif ($user['type'] === "client") {
        $redirect = "client_dashboard.php";
    }

    echo json_encode(["success" => true, "redirect" => $redirect]);
} else {
    echo json_encode(["success" => false, "message" => "Email ou mot de passe incorrect."]);
}

$conn->close();
?>
