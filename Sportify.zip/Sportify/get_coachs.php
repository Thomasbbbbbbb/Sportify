<?php
$conn = new mysqli("localhost", "root", "", "sportify");
if ($conn->connect_error) {
    http_response_code(500);
    exit("Erreur de connexion à la BDD.");
}

$result = $conn->query("
    SELECT coachs.nom, coachs.specialite, coachs.photo, coachs.disponibilite, coachs.cv, comptes.email
    FROM coachs
    JOIN comptes ON coachs.nom = comptes.nom
    WHERE comptes.type = 'coach'
");

$coachs = [];
while ($row = $result->fetch_assoc()) {
    $coachs[] = $row;
}

header("Content-Type: application/json");
echo json_encode($coachs);