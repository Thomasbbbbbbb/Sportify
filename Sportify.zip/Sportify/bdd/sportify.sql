-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : sam. 31 mai 2025 à 15:04
-- Version du serveur : 9.1.0
-- Version de PHP : 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `sportify`
--

-- --------------------------------------------------------

--
-- Structure de la table `cartes_bancaires`
--

DROP TABLE IF EXISTS `cartes_bancaires`;
CREATE TABLE IF NOT EXISTS `cartes_bancaires` (
  `id` int NOT NULL AUTO_INCREMENT,
  `numero` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `nom` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `expiration` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `cvv` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `moyen` enum('visa','mastercard','american express','paypal') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `coachs`
--

DROP TABLE IF EXISTS `coachs`;
CREATE TABLE IF NOT EXISTS `coachs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'Nom du coach',
  `specialite` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'Sport pratiqué',
  `id_service` int NOT NULL,
  `email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'Email du coach',
  `photo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'Nom du fichier image',
  `cv` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'Fichier xml',
  `disponibilite` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `video` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'Fichier mp4/youtube',
  `bureau` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `coachs`
--

INSERT INTO `coachs` (`id`, `nom`, `specialite`, `id_service`, `email`, `photo`, `cv`, `disponibilite`, `video`, `bureau`) VALUES
(1, 'Alex Durand', 'Basketball', 1, 'alex.durand@omnes.com', 'images/alex.jpeg', 'cv/alex_durand_cv.xml', 'Lundi : 9h-12h, 14h-17h\r\nMardi : absent\r\nMercredi : 10h-16h\r\nJeudi : 9h-12h\r\nVendredi : 13h-18h\r\nSamedi : 9h-22h\r\n', '', NULL),
(2, 'Marc Moreau', 'Rugby', 2, 'marc.moreau@omnes.com', 'images/marc.jpeg', 'cv/marc_moreau_cv.xml', 'Lundi : 9h-12h, 14h-17h\r\nMardi : absent\r\nMercredi : 10h-16h\r\nJeudi : 9h-12h\r\nVendredi : 13h-18h\r\nSamedi : 9h-12h\r\n', '', NULL),
(3, 'Titouan Lefèvre', 'Tennis', 3, 'titouan.lefevre@omnes.com', 'images/titouan.jpeg', 'cv/titouan_lefevre_cv.xml', 'Lundi : 10h-12h, 14h-18h\nMardi : 9h-12h\nMercredi : absent\nJeudi : 13h-17h\nVendredi : 10h-16h\nSamedi : 9h-12h', '', 'Bureau 103'),
(4, 'Patrick Bernard', 'Football', 4, 'patrick.bernard@omnes.com', 'images/patrick.jpeg', 'cv/patrick_bernard_cv.xml', 'Lundi : absent\r\nMardi : 10h-13h\r\nMercredi : 14h-18h\r\nJeudi : 9h-12h\r\nVendredi : 13h-17h\r\nSamedi : absent', '', NULL),
(5, 'Hugo Fontaine', 'Natation', 5, 'hugo.fontaine@omnes.com', 'images/hugo.jpeg', 'cv/hugo_fontaine_cv.xml', 'Lundi : 8h-11h, 14h-17h\nMardi : 8h-11h\nMercredi : absent\nJeudi : 10h-13h\nVendredi : 15h-18h\nSamedi : 10h-12h', '', NULL),
(6, 'Luc Morel', 'Musculation', 6, 'luc.morel@omnes.com', 'images/luc.jpeg', 'cv/luc_morel_cv.xml', 'Lundi : 9h-12h, 14h-16h\r\nMardi : 10h-13h\r\nMercredi : 13h-17h\r\nJeudi : 9h-12h\r\nVendredi : 14h-18h\r\nSamedi : absent', '', 'Bureau 106'),
(7, 'Sophie Garnier', 'Fitness', 7, 'sophie.garnier@omnes.com', 'images/sophie.jpeg', 'cv/sophie_garnier_cv.xml', 'Lundi : 8h-11h, 13h-16h\nMardi : 8h-12h\nMercredi : 14h-18h\nJeudi : 10h-13h\nVendredi : 15h-17h\nSamedi : 10h-12h', '', 'Bureau 107'),
(8, 'Nicolas Leclerc', 'Biking', 8, 'nicolas.leclerc@omnes.com', 'images/nicolas.jpeg', 'cv/nicolas_leclerc_cv.xml', 'Lundi : 10h-12h, 14h-17h\r\nMardi : 9h-11h\r\nMercredi : 13h-15h\r\nJeudi : 10h-12h\r\nVendredi : 14h-18h\r\nSamedi : absent', '', 'Bureau 108'),
(9, 'Camille Dubois', 'Cardio-Training', 9, 'camille.dubois@omnes.com', 'images/camille.jpeg', 'cv/camille_dubois_cv.xml', 'Lundi : 7h-10h, 12h-15h\nMardi : 10h-14h\nMercredi : 8h-11h\nJeudi : 13h-17h\nVendredi : 9h-12h\nSamedi : 11h-13h', '', 'Bureau 109'),
(10, 'Julien Lefevre', 'Cours Collectifs', 10, 'julien.lefevre@omnes.com', 'images/julien.jpeg', 'cv/julien_lefevre_cv.xml', 'Lundi : 9h-11h, 15h-18h\r\nMardi : 11h-13h\r\nMercredi : 10h-14h\r\nJeudi : 9h-12h\r\nVendredi : 13h-16h\r\nSamedi : 9h-11h', '', 'Bureau 110');

-- --------------------------------------------------------

--
-- Structure de la table `comptes`
--

DROP TABLE IF EXISTS `comptes`;
CREATE TABLE IF NOT EXISTS `comptes` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT 'Identifiant Unique',
  `nom` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'Nom d''utilisateur',
  `email` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'Adresse mail',
  `mot_de_passe` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'Mot de passe',
  `type` enum('admin','coach','client') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'Type de compte',
  `adresse` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `carte_etudiante` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT NULL,
  `info_paiement` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `comptes`
--

INSERT INTO `comptes` (`id`, `nom`, `email`, `mot_de_passe`, `type`, `adresse`, `carte_etudiante`, `info_paiement`) VALUES
(1, 'admin', 'admin@test.com', 'admin123', 'admin', NULL, NULL, NULL),
(3, 'Alex Durand', 'alex.durand@omnes.com', 'alexdurand123', 'coach', NULL, NULL, NULL),
(4, 'Neuille Pro', 'neuille.pro@omnes.com', 'neuille123', 'client', NULL, NULL, NULL),
(6, 'Client Test', 'client.test@omnes.com', 'client123', 'client', '23 rue test', 'G-293123', NULL),
(7, 'Système', 'system@site.com', '1234567890', 'coach', NULL, NULL, NULL),
(8, 'thomas', 'thomasboulier05@gmail.com', 'Thomas2005', 'client', NULL, NULL, NULL),
(9, 'Marc Moreau', 'marc.moreau@omnes.com', 'marcmoreau123', 'coach', NULL, NULL, NULL),
(10, 'Titouan Lefèvre', 'titouan.lefevre@omnes.com', 'titouanlefevre123', 'coach', NULL, NULL, NULL),
(11, 'Patrick Bernard', 'patrick.bernard@omnes.com', 'patrickbernard123', 'coach', NULL, NULL, NULL),
(12, 'Hugo Fontaine', 'hugo.fontaine@omnes.com', 'hugofontaine12', 'coach', NULL, NULL, NULL),
(13, 'Luc Morel', 'luc.morel@omnes.com', 'lucmorel123', 'coach', NULL, NULL, NULL),
(14, 'Sophie Garnier', 'sophie.garnier@omnes.com', 'sophiegarnier123', 'coach', NULL, NULL, NULL),
(15, 'Nicolas Leclerc', 'nicolas.leclerc@omnes.com', 'nicolasleclerc12', 'coach', NULL, NULL, NULL),
(16, 'Camille Dubois', 'camille.dubois@gmail.com', 'camilledubois12', 'coach', NULL, NULL, NULL),
(17, 'Julien Lefevre', 'julien.lefevre@omnes.com', 'julienlefevre123', 'coach', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sender_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'Email du "sender"',
  `receiver_email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'Email du receveur',
  `contenu` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL COMMENT 'Le contenu du message',
  `date_envoi` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Date de l''envoie du msg',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `messages`
--

INSERT INTO `messages` (`id`, `sender_email`, `receiver_email`, `contenu`, `date_envoi`) VALUES
(1, 'alex.durand@omnes.com', 'neuille.pro@omnes.com', 'salut', '2025-05-27 19:30:37'),
(2, 'alex.durand@omnes.com', 'neuille.pro@omnes.com', 'test', '2025-05-27 19:32:50'),
(3, 'alex.durand@omnes.com', 'neuille.pro@omnes.com', 'Bonjour HIHIHIHIAIDHAUWIGBAUY GWUW', '2025-05-27 19:35:00'),
(4, 'alex.durand@omnes.com', 'neuille.pro@omnes.com', 'test', '2025-05-27 20:07:37'),
(5, 'neuille.pro@omnes.com', 'alex.durand@omnes.com', 'Salut', '2025-05-28 12:09:51'),
(6, 'client.test@omnes.com', 'alex.durand@omnes.com', 'Salut', '2025-05-28 12:37:26'),
(7, 'system@site.com', 'client.test@omnes.com', '✅ Paiement confirmé pour \'Seance de Musculation\' via Visa. Total : 25€.', '2025-05-28 14:16:23'),
(8, 'system@site.com', 'client.test@omnes.com', '✅ Paiement confirmé pour \'Seance de Musculation\' via MasterCard. Total : 25€.', '2025-05-28 14:17:39'),
(9, 'system@site.com', 'client.test@omnes.com', '✅ Paiement confirmé pour le service **\"Seance de Musculation\"** :\r\n\r\n📅 Date : 30/05/2025 13:23  \r\n📍 Lieu : Salle 2  \r\n💳 Moyen : Visa  \r\n💰 Montant : 25.00 €  \r\n📝 Description : Blablabla\r\n\r\nMerci pour votre confiance !', '2025-05-28 14:20:40'),
(10, 'system@site.com', 'client.test@omnes.com', '✅ Paiement confirmé pour le service **\"Seance de Musculation\"** :\r\n\r\n📅 Date : 30/05/2025 13:23  \r\n📍 Lieu : Salle 2  \r\n💳 Moyen : Visa  \r\n💰 Montant : 25.00 €  \r\n📝 Description : Blablabla\r\n\r\nMerci pour votre confiance !', '2025-05-28 14:23:33'),
(11, 'system@site.com', 'client.test@omnes.com', '✅ Paiement confirmé pour le service **\"Seance de Musculation\"** :\n\r\n\r\n📅 Date : 30/05/2025 13:23  \r\n📍 Lieu : Salle 2  \r\n💳 Moyen : Visa  \r\n💰 Montant : 25.00 €  \r\n📝 Description : Blablabla\r\n\r\nMerci pour votre confiance !', '2025-05-28 14:27:48'),
(12, 'system@site.com', 'client.test@omnes.com', '✅ Paiement confirmé pour le service **Seance de Musculation**\n📅 Date : 01/01/1970 00:00\n💶 Montant : 25 €\n💳 Moyen : Visa', '2025-05-28 14:28:44'),
(13, 'system@site.com', 'client.test@omnes.com', '✅ Paiement confirmé pour le service **\"Seance de Musculation\"** :\n\r\n\r\n📅 Date : 30/05/2025 13:23  \r\n📍 Lieu : Salle 2  \r\n💳 Moyen : Visa  \r\n💰 Montant : 25.00 €  \r\n📝 Description : Blablabla\r\n\r\nMerci pour votre confiance !', '2025-05-28 14:37:13'),
(14, 'alex.durand@omnes.com', 'neuille.pro@omnes.com', 'Bonjour', '2025-05-31 14:32:13'),
(15, 'client.test@omnes.com', 'julien.lefevre@omnes.com', 'hey!', '2025-05-31 15:10:07'),
(16, 'system@site.com', 'client.test@omnes.com', '✅ Votre rendez-vous a bien été enregistré :  \r\n\r\n🧑‍🏫 Coach : Alex Durand  \r\n📅 Jour : Mercredi  \r\n🕒 Heure : 11:40  \r\n🏷️ Service : Séance de Basketball  \r\n📝 Description : Sport collectif rapide et dynamique où deux équipes s\'affrontent pour marquer des paniers. Améliore coordination, explosivité et esprit d’équipe.  \r\n\r\n📍 Lieu : Salle 1  \r\n\r\nMerci pour votre confiance, à bientôt avec votre coach ! 🏋️‍♂️', '2025-05-31 15:16:25');

-- --------------------------------------------------------

--
-- Structure de la table `paiements`
--

DROP TABLE IF EXISTS `paiements`;
CREATE TABLE IF NOT EXISTS `paiements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_client` int NOT NULL,
  `id_rdv` int NOT NULL,
  `montant` decimal(6,2) NOT NULL,
  `moyen` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `statut` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `rdv`
--

DROP TABLE IF EXISTS `rdv`;
CREATE TABLE IF NOT EXISTS `rdv` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_client` int NOT NULL,
  `id_coach` int NOT NULL,
  `date` datetime NOT NULL,
  `lieu` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `id_service` int NOT NULL,
  `statut` enum('à venir','passé','annulé') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'à venir',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `rdv`
--

INSERT INTO `rdv` (`id`, `id_client`, `id_coach`, `date`, `lieu`, `id_service`, `statut`) VALUES
(1, 6, 1, '2025-05-29 13:16:30', 'Salle 1', 0, 'annulé'),
(2, 6, 3, '2025-05-27 13:22:37', 'Salle 3', 0, 'passé'),
(3, 6, 1, '2025-05-30 13:23:31', 'Salle 2', 1, 'passé'),
(4, 6, 1, '2025-06-02 09:00:00', 'Salle 1', 0, 'à venir'),
(5, 6, 1, '2025-06-02 09:20:00', 'Salle 1', 0, 'annulé'),
(6, 6, 1, '2025-06-02 09:40:00', 'Salle 1', 0, 'à venir'),
(7, 6, 6, '2025-06-02 10:00:00', 'Salle 1', 0, 'à venir'),
(8, 6, 1, '2025-06-02 10:00:00', 'Salle 1', 0, 'à venir'),
(9, 6, 1, '2025-06-02 10:20:00', 'Salle 1', 0, 'à venir'),
(10, 6, 1, '2025-06-02 10:40:00', 'Salle 1', 0, 'à venir'),
(11, 4, 1, '2025-06-05 10:00:00', 'Salle 1', 0, 'à venir'),
(12, 6, 6, '2025-06-05 11:40:00', 'Salle 1', 6, 'annulé'),
(13, 6, 1, '2025-06-04 12:20:00', 'Salle 1', 1, 'à venir'),
(14, 6, 3, '2025-06-02 16:40:00', 'Salle 1', 1, 'annulé'),
(15, 6, 3, '2025-06-04 11:40:00', 'Salle 1', 1, 'à venir');

-- --------------------------------------------------------

--
-- Structure de la table `salle_service`
--

DROP TABLE IF EXISTS `salle_service`;
CREATE TABLE IF NOT EXISTS `salle_service` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_salle` int NOT NULL,
  `id_service` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `salle_service`
--

INSERT INTO `salle_service` (`id`, `id_salle`, `id_service`) VALUES
(1, 2, 1),
(2, 2, 2),
(3, 2, 3),
(4, 2, 4),
(5, 2, 5),
(6, 1, 6),
(7, 1, 7),
(8, 1, 8),
(9, 1, 9),
(10, 1, 10);

-- --------------------------------------------------------

--
-- Structure de la table `salle_sport`
--

DROP TABLE IF EXISTS `salle_sport`;
CREATE TABLE IF NOT EXISTS `salle_sport` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom_salle` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `numero` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `telephone` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `photo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `salle_sport`
--

INSERT INTO `salle_sport` (`id`, `nom_salle`, `numero`, `telephone`, `email`, `photo`, `description`) VALUES
(1, 'Salle de sport Omnes', 'G-001', '+33 01 22 33 44 55', 'salle.sport@omnessports.fr', 'images/salle_sport.jpg', 'La Salle de Sport Omnes est un complexe moderne et polyvalent destiné à tous les profils sportifs. Elle propose un espace musculation complet, des machines de cardio-training connectées, un coin stretching, ainsi que des cours collectifs encadrés par nos coachs certifiés. Ouverte toute la semaine, elle favorise une pratique sportive régulière dans un cadre motivant, propre et sécurisé.\r\n\r\n'),
(2, 'Centre de sport Omnes', 'G-002', '+33 01 22 39 48 31', 'salle.basket@omnessports.fr', 'images/salle_sport.jpg', 'Le Centre de Sports Omnes est une installation dédiée aux sports de compétition, regroupant plusieurs disciplines telles que le basketball, le football, le rugby, le tennis, la natation et le plongeon. Conçu pour accueillir des entraînements de haut niveau comme des activités accessibles à tous, le centre met à disposition des terrains spécialisés, des vestiaires équipés, et des coachs certifiés.\r\n\r\nGrâce à une organisation optimale, chaque discipline dispose de créneaux dédiés, et les adhérents peuvent réserver des séances individuelles ou collectives. Ce centre est l’endroit idéal pour développer son esprit d’équipe, améliorer ses performances et découvrir la pratique encadrée de sports dynamiques dans un cadre stimulant et professionnel.');

-- --------------------------------------------------------

--
-- Structure de la table `services`
--

DROP TABLE IF EXISTS `services`;
CREATE TABLE IF NOT EXISTS `services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci NOT NULL,
  `prix` decimal(6,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `services`
--

INSERT INTO `services` (`id`, `nom`, `description`, `prix`) VALUES
(1, 'Séance de Basketball', 'Sport collectif rapide et dynamique où deux équipes s\'affrontent pour marquer des paniers. Améliore coordination, explosivité et esprit d’équipe.', 25.00),
(2, 'Séance de Rugby', 'Sport de contact et d’intensité qui demande force, stratégie et cohésion. Idéal pour développer l’endurance et le mental.\r\n\r\n', 25.00),
(3, 'Séance de Tennis', 'Sport de raquette demandant agilité, puissance, précision et réactivité. Excellent pour le cardio et la concentration.', 25.00),
(4, 'Séance de Football', 'Le sport collectif par excellence. Technique, vitesse et travail d’équipe sont les clés de ce jeu mondialement populaire.', 25.00),
(5, 'Séance de Natation', 'Discipline complète sollicitant tout le corps. Améliore l’endurance, la respiration, la tonicité et préserve les articulations.', 25.00),
(6, 'Séance de Musculation', 'Entraînement visant à développer la masse musculaire et la force physique, à l’aide de poids, machines ou exercices au poids du corps.', 40.00),
(7, 'Séance de Fitness', 'Activité physique complète mêlant cardio, renforcement musculaire et souplesse. Objectif : améliorer la forme générale et le bien-être.', 40.00),
(8, 'Séance de Biking', 'Cours de vélo en salle, en musique et en groupe, basé sur le rythme et l’intensité. Excellent pour le cardio et la perte de poids.', 40.00),
(9, 'Séance de Cardio-Training', 'Entraînement basé sur l\'endurance et le travail du cœur : course, vélo, rameur, elliptique, etc. Favorise la santé cardiovasculaire.', 40.00),
(10, 'Séance de Cours Collectifs', 'Ensembles d’activités en groupe encadrées par un coach : zumba, HIIT, pilates, body attack... Idéal pour se motiver à plusieurs.', 40.00);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
