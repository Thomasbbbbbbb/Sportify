document.addEventListener("DOMContentLoaded", function () {
  const section = document.getElementById("main-section");
  const btnAccueil = document.getElementById("btn-accueil");
  const btnParcourir = document.getElementById("btn-parcourir");
  const btnCompte = document.getElementById("btn-compte");
  const btnRDV = document.getElementById("btn-rdv");
  const btnRecherche = document.getElementById("btn-recherche");

  //  Page d'accueil avec carrousel et Google Map
  btnAccueil.addEventListener("click", function () {
    section.innerHTML = `
      <h2>Bienvenue sur Sportify</h2>
      <p>Sportify est la plateforme officielle de consultation sportive de la communauté Omnes Education. Réservez vos rendez-vous en ligne avec nos coachs sportifs ou explorez notre salle de sport connectée.</p>

      <div class="event">
        <h3>📣 Évènement de la semaine</h3>
        <p>Portes ouvertes Sportify - Samedi 31 mai : Venez découvrir nos installations et rencontrer nos coachs !</p>
      </div>

      <div class="carousel-wrapper">
        <h3>👥 Nos spécialistes</h3>
        <button class="carousel-btn left" onclick="scrollCarousel(-1)">&#10094;</button>
        <div class="carousel" id="carousel"></div>
        <button class="carousel-btn right" onclick="scrollCarousel(1)">&#10095;</button>
      </div>

      <div class="map-container">
        <h3>📍 Où nous trouver ?</h3>
        <div id="map"></div>
      </div>
    `;

    fetch("get_coachs.php")
      .then(response => response.json())
      .then(coachs => {
        const carousel = document.getElementById("carousel");
        carousel.innerHTML = coachs.map(coach => `
          <div class="carousel-item" onclick="afficherCoach('${coach.nom.replace(/'/g, "\\'")}')">
            <img src="${coach.photo}" alt="${coach.specialite}">
            <p>${coach.nom}<br><strong>${coach.specialite}</strong></p>
          </div>
        `).join("");
      })
      .catch(error => {
        console.error("Erreur lors du chargement des coachs :", error);
        document.getElementById("carousel").innerHTML = "<p>Erreur de chargement des coachs.</p>";
      });

    if (typeof initMap === "function") {
      initMap();
    }
  });

  //  Page "Tout parcourir" 
  btnParcourir.addEventListener("click", afficherToutParcourir);

  btnRecherche.addEventListener("click", () => {
    const section = document.getElementById("main-section");
    section.innerHTML = `
      <h2>🔎 Rechercher un coach, une spécialité ou un établissement</h2>
      <div style="display: flex; gap: 10px; margin: 20px 0;">
        <input id="searchInput" type="text" placeholder="Nom, spécialité ou établissement" style="flex: 1; padding: 12px; font-size: 1rem; border-radius: 6px; border: 1px solid #ccc;">
        <button onclick="effectuerRecherche()" style="padding: 12px 20px; background: #f39c12; color: white; border: none; border-radius: 6px; font-weight: bold; cursor: pointer;">Rechercher</button>
      </div>
      <div id="searchResults"></div>
    `;
  });

  btnRDV.addEventListener("click", () => {
    fetch("check_session.php")
      .then(res => res.json())
      .then(data => {
        if (data.connecte && data.type === "client") {
          afficherTimelineRdv();
        } else {
          document.getElementById("loginModal").classList.add("active");
        }
      })
      .catch(() => {
        alert("❌ Erreur de session");
      });
  });

  btnCompte.addEventListener("click", function (e) {
    e.preventDefault();
    document.getElementById("loginModal").classList.add("active");
  });
});

// fonctions 

function afficherToutParcourir() {
  const section = document.getElementById("main-section");
  section.innerHTML = `
    <h2>🎯 Parcourez nos catégories sportives</h2>

    <div class="categorie">
      <h3>🏋️ Activités sportives</h3>
      <ul>
        <li><button onclick="afficherCategorie('Musculation')">Musculation</button></li>
        <li><button onclick="afficherCategorie('Fitness')">Fitness</button></li>
        <li><button onclick="afficherCategorie('Biking')">Biking</button></li>
        <li><button onclick="afficherCategorie('Cardio-Training')">Cardio-Training</button></li>
        <li><button onclick="afficherCategorie('Cours Collectifs')">Cours Collectifs</button></li>
      </ul>
    </div>

    <div class="categorie">
      <h3>🏆 Sports de compétition</h3>
      <ul>
        <li><button onclick="afficherCategorie('Basketball')">Basketball</button></li>
        <li><button onclick="afficherCategorie('Football')">Football</button></li>
        <li><button onclick="afficherCategorie('Rugby')">Rugby</button></li>
        <li><button onclick="afficherCategorie('Tennis')">Tennis</button></li>
        <li><button onclick="afficherCategorie('Natation')">Natation</button></li>
      </ul>
    </div>

    <div class="categorie">
      <h3>🏢 Salle de sport Omnes</h3>
      <ul>
        <li><button onclick="afficherSallesSport()">Voir toutes les salles disponibles</button></li>
      </ul>
    </div>
  `;
}

function afficherCategorie(specialite) {
  const section = document.getElementById("main-section");
  section.innerHTML = `<h2>🔎 ${specialite}</h2><div id="coachsList" class="coachs-grid"></div>`;
  
  fetch("get_coachs.php")
    .then(res => res.json())
    .then(coachs => {
      const filteredCoachs = coachs.filter(c => 
        c.specialite.toLowerCase() === specialite.toLowerCase()
      );
      
      const coachsList = document.getElementById("coachsList");
      
      if (filteredCoachs.length === 0) {
        coachsList.innerHTML = "<p>Aucun coach trouvé pour cette spécialité.</p>";
        return;
      }
      
      coachsList.innerHTML = filteredCoachs.map(coach => `
        <div class="coach-card" onclick="afficherCoach('${coach.nom.replace(/'/g, "\\'")}')">
          <img src="${coach.photo}" alt="${coach.nom}">
          <div class="coach-info">
            <h3>${coach.nom}</h3>
            <p>${coach.specialite}</p>
            <p class="coach-email">${coach.email}</p>
          </div>
        </div>
      `).join("");
    })
    .catch(err => {
      console.error("Erreur de chargement des coachs :", err);
      section.innerHTML = "<p>❌ Erreur lors du chargement des données.</p>";
    });
}


function afficherCoach(nomCoach) {
  fetch("get_coachs.php")
    .then(response => response.json())
    .then(coachs => {
      const normalize = str => str.trim().normalize("NFD").replace(/\p{Diacritic}/gu, "").toLowerCase();
      const coach = coachs.find(c => normalize(c.nom) === normalize(nomCoach));

      if (coach) {
        const section = document.getElementById("main-section");

        section.innerHTML = `
          <div style="border: 2px solid #ccc; border-radius: 20px; padding: 20px; max-width: 900px; margin: auto; background: #f7f7f7;">
            <div style="display: flex; gap: 20px; align-items: center;">
              <img src="${coach.photo}" alt="${coach.nom}" style="max-width:180px; border-radius: 10px; border: 2px solid #555;">
              <div>
                <h2 style="margin: 0;">${coach.nom}</h2>
                <h3 style="margin: 5px 0;">Coach, ${coach.specialite}</h3>
                <p><strong>Salle :</strong> ${coach.bureau && coach.bureau !== "null" ? coach.bureau : "Non renseigné"}</p>
                <p><strong>Email :</strong> <a href="mailto:${coach.email}">${coach.email}</a></p>
              </div>
            </div>

            <h4 style="margin-top: 20px;">Emploi du temps</h4>
            <table style="width: 100%; border-collapse: collapse; text-align: center; margin-bottom: 20px;">
              <thead>
                <tr style="background: #dcdcdc;">
                  <th style="padding: 8px; border: 1px solid #999;">Jour</th>
                  <th style="padding: 8px; border: 1px solid #999;">AM</th>
                  <th style="padding: 8px; border: 1px solid #999;">PM</th>
                </tr>
              </thead>
              <tbody>
                ${["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"].map(jour => {
                  const dispo = coach.disponibilite.toLowerCase();
                  let am = false;
                  let pm = false;

                  if (dispo.includes(jour.toLowerCase())) {
                    const jourRegex = new RegExp(`${jour.toLowerCase()}\\s*:\\s*([^\\n]*)`, 'i');
                    const match = dispo.match(jourRegex);

                    if (match && match[1]) {
                      const plages = match[1].split(',');
                      for (const plage of plages) {
                        if (plage.match(/\d{1,2}h-\d{1,2}h/)) {
                          const [h1, h2] = plage.match(/\d{1,2}/g).map(Number);
                          if (h1 < 12) am = true;
                          if (h2 > 12 || (h1 >= 12 && h2 >= 12)) pm = true;
                        } else if (plage.includes("matin")) {
                          am = true;
                        } else if (plage.includes("après-midi") || plage.includes("apres-midi")) {
                          pm = true;
                        }
                      }
                    }
                  }

                  return `
                    <tr>
                      <td style="padding: 8px; border: 1px solid #999;">${jour}</td>
                      <td style="padding: 8px; border: 1px solid #999; background: ${am ? '#fff' : '#000'};"></td>
                      <td style="padding: 8px; border: 1px solid #999; background: ${pm ? '#fff' : '#000'};"></td>
                    </tr>
                  `;
                }).join("")}
              </tbody>
            </table>

            <div style="display: flex; gap: 15px; justify-content: center;">
              <button onclick="afficherCalendrierCoach('${coach.nom}')" style="padding: 12px 20px; background: #2ecc71; color: white; border: none; border-radius: 10px; font-weight: bold; cursor: pointer;">📅 Prendre un RDV</button>
              <a href="chatroom.php?with=${encodeURIComponent(coach.email)}" style="padding: 12px 20px; background: #74b9ff; color: black; border: none; border-radius: 10px; font-weight: bold; text-decoration: none;">💬 Communiquer avec le coach</a>
              <a href="voir_cv.php?file=${coach.cv}" target="_blank" style="padding: 12px 20px; background: #dfe6e9; color: black; border: none; border-radius: 10px; font-weight: bold; text-decoration: none;">📄 Voir son CV</a>
            </div>

            <div style="text-align: center; margin-top: 20px;">
              <button onclick="afficherToutParcourir()" style="margin-top: 20px; padding: 10px 15px; background: #bbb; border-radius: 6px; border: none; font-weight: bold;">🔙 Retour</button>
            </div>
          </div>
        `;
      } else {
        alert("Coach introuvable.");
      }
    })
    .catch(error => {
      console.error("Erreur lors du chargement du coach :", error);
    });
}

function afficherCalendrierCoach(nomCoach) {
  fetch("get_creneaux.php?coach=" + encodeURIComponent(nomCoach))
    .then(response => response.json())
    .then(data => {
      const section = document.getElementById("main-section");
      const jours = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi"];

      const creneaux = [];
      for (let h = 9; h <= 22; h++) {
        [":00", ":20", ":40"].forEach(m => {
          creneaux.push(("0" + h).slice(-2) + m);
        });
      }

      section.innerHTML = `<h2>📅 Prise de rendez-vous avec ${nomCoach}</h2>
        <table style="border-collapse: collapse; width: 100%; text-align: center;">
          <thead>
            <tr>
              <th style="border: 1px solid #999; padding: 8px;">Horaire</th>
              ${jours.map(j => `<th style="border: 1px solid #999; padding: 8px;">${j}</th>`).join("")}
            </tr>
          </thead>
          <tbody>
            ${creneaux.map(h => `
              <tr>
                <td style="border: 1px solid #999; padding: 6px;">${h}</td>
                ${jours.map(jour => {
                  const etat = data[jour]?.[h] ?? "indisponible";
                  let style = "background: black;";
                  let clickable = "";
                  let contenu = "";

                  if (etat === "disponible") {
                    style = "background: white; cursor: pointer;";
                    clickable = `onclick=\"reserverCreneau('${nomCoach}', '${jour}', '${h}')\"`;
                  } else if (etat === "pris") {
                    style = "background: #3498db; color: white;";
                    contenu = "Occupé";
                  }

                  return `<td style=\"border: 1px solid #999; ${style}\" ${clickable}>${contenu}</td>`;
                }).join("")}
              </tr>
            `).join("")}
          </tbody>
        </table>
        <div style="text-align:center; margin-top:20px;">
          <button onclick="afficherCoach('${nomCoach}')" style="margin-top: 20px; padding: 10px 15px; background: #bbb; border-radius: 6px; border: none; font-weight: bold;">🔙 Retour</button>
        </div>
      `;
    })
    .catch(err => {
      console.error("Erreur chargement créneaux :", err);
      document.getElementById("main-section").innerHTML = "<p>❌ Erreur chargement du calendrier.</p>";
    });
}

function reserverCreneau(nomCoach, jour, horaire) {
  const formData = new FormData();
  formData.append("coach", nomCoach);
  formData.append("jour", jour);
  formData.append("heure", horaire);

  fetch("reserver_creneau.php", {
    method: "POST",
    body: formData
  })
    .then(response => response.json())
    .then(data => {
      if (data.success) {
        alert(data.message);
        const jours = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi"];
        const colonneIndex = jours.indexOf(jour) + 1;
        const lignes = document.querySelectorAll('table tr');
        
        for (let ligne of lignes) {
          const celluleHoraire = ligne.cells[0];
          if (celluleHoraire && celluleHoraire.textContent.trim() === horaire) {
            const cellule = ligne.cells[colonneIndex];
            cellule.style.background = "#3498db";
            cellule.style.color = "white";
            cellule.textContent = "Occupé";
            cellule.onclick = null;
            break;
          }
        }
      } else {
        alert(data.message || "❌ Erreur lors de la réservation.");
      }
    })
    .catch(() => {
      alert("❌ Erreur lors de la réservation.");
    });
}

function scrollCarousel(direction) {
  const carousel = document.getElementById("carousel");
  if (carousel) {
    const step = 220;
    carousel.scrollBy({ left: direction * step, behavior: "smooth" });
  }
}

function initMap() {
  const sportifyLocation = { lat: 48.878014, lng: 2.292831 };
  const map = new google.maps.Map(document.getElementById("map"), {
    zoom: 16,
    center: sportifyLocation
  });
  new google.maps.Marker({ position: sportifyLocation, map: map, title: "Sportify - 4 avenue des Ternes, Paris" });
}

function afficherTimelineRdv() {
  fetch("rendezvous_client.php")
    .then(res => res.text())
    .then(html => {
      document.getElementById("main-section").innerHTML = html;
    })
    .catch(() => {
      document.getElementById("main-section").innerHTML = "<p>❌ Erreur chargement des rendez-vous</p>";
    });
}

function effectuerRecherche() {
  const query = document.getElementById("searchInput").value.trim();
  const resultsDiv = document.getElementById("searchResults");

  if (!query) {
    resultsDiv.innerHTML = "<p>❌ Veuillez entrer une recherche.</p>";
    return;
  }

  resultsDiv.innerHTML = "<p>🔄 Recherche en cours...</p>";

  fetch("recherche.php?q=" + encodeURIComponent(query))
    .then(res => res.json())
    .then(data => {
      if (!Array.isArray(data) || data.length === 0) {
        resultsDiv.innerHTML = "<p>❌ Aucun résultat trouvé.</p>";
        return;
      }

      resultsDiv.innerHTML = data.map(item => {
        if (item.type === "coach") {
          return `
            <div class="result-card" style="animation: fadeInResult 0.4s ease;">
              <img src="${item.photo}" alt="photo" style="width: 100px; height: 100px; border-radius: 10px; object-fit: cover;">
              <div>
                <h3>${item.nom}</h3>
                <p><strong>Spécialité :</strong> ${item.specialite}</p>
                <p><strong>Salle :</strong> ${item.bureau ?? "Non renseignée"}</p>
                <p><strong>Email :</strong> <a href="mailto:${item.email}">${item.email}</a></p>
                <div style="margin-top: 10px;">
                  <button onclick="afficherCoach('${item.nom.replace(/'/g, "\\'")}')" 
                    style="padding: 6px 12px; background: #2ecc71; color: white; border: none; border-radius: 6px;">
                    Voir Profil
                  </button>
                  <a href="voir_cv.php?file=${encodeURIComponent(item.cv)}" target="_blank" 
                    style="margin-left: 10px; padding: 6px 12px; background: #bdc3c7; color: black; text-decoration: none; border-radius: 6px;">
                    CV
                  </a>
                </div>
              </div>
            </div>
          `;
        }

        if (item.type === "salle") {
          return `
            <div class="result-card" style="animation: fadeInResult 0.4s ease;">
              <img src="${item.photo}" alt="salle" style="width: 100px; height: 100px; border-radius: 10px; object-fit: cover;">
              <div>
                <h3>${item.nom}</h3>
                <p>${item.description}</p>
                <p><strong>📧 Contact :</strong> <a href="mailto:${item.email}">${item.email}</a></p>
              </div>
            </div>
          `;
        }

        if (item.type === "activite") {
          const sport = encodeURIComponent(item.nom.replace("Séance de ", ""));
          return `
            <div class="result-card" style="text-align:center; animation: fadeInResult 0.4s ease;">
              <h3>${item.nom}</h3>
              <a href="#" onclick="afficherCategorie('${sport}')" 
                 style="display:inline-block; margin-top:10px; color:#2980b9; font-weight:bold;">
                🔎 Voir cette activité
              </a>
            </div>
          `;
        }

        return "";
      }).join("");
    })
    .catch(err => {
      console.error(err);
      resultsDiv.innerHTML = "<p>❌ Erreur lors de la recherche.</p>";
    });
}

function afficherSallesSport() {
  fetch("get_salles.php")
    .then(res => res.json())
    .then(salles => {
      const section = document.getElementById("main-section");
      section.innerHTML = `
        <div class="salle-header">
          <h2>🏢 Nos salles de sport</h2>
          <button onclick="afficherServicesSalle()" class="btn-services">
            Nos services
          </button>
        </div>
        <div id="salles-container"></div>
      `;

      const container = document.getElementById("salles-container");
      
      salles.forEach(salle => {
        const servicesHTML = salle.services.map(service => `
          <div class="service-item">
            <p><strong>${service.nom}</strong> — ${service.description}</p>
            <p class="service-price">💶 ${parseFloat(service.prix).toFixed(2)} €</p>
            <button onclick="effectuerRechercheDepuisService('${service.nom.replace(/'/g, "\\'")}')" class="btn-service">
              📅 Prendre RDV
            </button>
          </div>
        `).join("");

        const salleCard = document.createElement("div");
        salleCard.className = "salle-card";
        salleCard.innerHTML = `
          <h3>🏛️ ${salle.nom_salle}</h3>
          <div class="salle-info">
            <p><strong>Salle :</strong> ${salle.numero}</p>
            <p><strong>Téléphone :</strong> ${salle.telephone}</p>
            <p><strong>Email :</strong> <a href="mailto:${salle.email}">${salle.email}</a></p>
          </div>
          <img src="${salle.photo}" alt="${salle.nom_salle}" class="salle-image">
          <p class="salle-description">${salle.description}</p>
          <div class="services-section">
            <h4>📋 Services disponibles :</h4>
            <div class="services-list">${servicesHTML}</div>
          </div>
        `;
        container.appendChild(salleCard);
      });
    })
    .catch(err => {
      console.error(err);
      document.getElementById("main-section").innerHTML = "<p>❌ Erreur lors du chargement des salles.</p>";
    });
}

function afficherServicesSalle() {
  const section = document.getElementById("main-section");
  
  section.innerHTML = `
    <div class="services-page">
      <button onclick="afficherSallesSport()" class="btn-back">
        ← Retour aux salles
      </button>
      
      <h2>🏢 Nos services</h2>
      
      <div class="services-grid">
        <!-- Service 1 -->
        <div class="service-card" onclick="afficherDetailService('personnel')">
          <div class="service-icon">👨‍🏫</div>
          <h3>Personnels de la salle</h3>
          <p>Découvrez notre équipe de professionnels</p>
        </div>
        
        <!-- Service 2 -->
        <div class="service-card" onclick="afficherDetailService('horaire')">
          <div class="service-icon">⏰</div>
          <h3>Horaire de la gym</h3>
          <p>Consultez nos horaires d'ouverture</p>
        </div>
        
        <!-- Service 3 -->
        <div class="service-card" onclick="afficherDetailService('regles')">
          <div class="service-icon">📜</div>
          <h3>Règles d'utilisation</h3>
          <p>Consignes pour les machines</p>
        </div>
        
        <!-- Service 4 -->
        <div class="service-card" onclick="afficherDetailService('nouveaux')">
          <div class="service-icon">🆕</div>
          <h3>Nouveaux clients</h3>
          <p>Informations pour les nouveaux membres</p>
        </div>
        
        <!-- Service 5 -->
        <div class="service-card" onclick="afficherDetailService('nutrition')">
          <div class="service-icon">🍎</div>
          <h3>Alimentation et nutrition</h3>
          <p>Conseils diététiques</p>
        </div>
      </div>
      
      <div id="service-details" class="service-details"></div>
    </div>
  `;
}

function reserverVisite(creneau, service) {
  if (!confirm(`Confirmer votre rendez-vous pour ${creneau} (${service}) ?`)) return;
  
 
  alert(`✅ Rendez-vous confirmé pour ${creneau} (${service})`);
  
  // retour aux salles après confirmation
  setTimeout(() => {
    afficherSallesSport();
  }, 1500);
}


function afficherDetailService(serviceId) {
  const detailsContainer = document.getElementById("service-details");
  const services = {
    personnel: {
      title: "Personnels de la salle de sport",
      content: `
        <h3>Notre équipe professionnelle</h3>
        <p>Nous disposons de 10 coachs diplômés dans divers domaines disponibles pour vous accompagner :</p>
        <ul>
          <li>coachs en musculation,tennis,rugby,foot,basket,fitness,biking etc...</li>
          
        </ul>
        <p>Tous nos coachs sont certifiés et à votre disposition pour des conseils personnalisés.</p>
      `
    },
    horaire: {
      title: "Horaire de la gym",
      content: `
        <h3>Horaires d'ouverture</h3>
        <ul>
          <li>Lundi-Vendredi: 7h-22h</li>
          <li>Samedi: 8h-22h</li>
          <li>Dimanche: 9h-22h</li>
        </ul>
        
        <h3>Cours collectifs</h3>
        <ul>
          <li>Yoga: Lundi/Jeudi 18h-19h</li>
          <li>Zumba: Mardi/Vendredi 19h-20h</li>
          <li>CrossFit: Mercredi/Samedi 10h-11h</li>
        </ul>
      `
    },
    regles: {
      title: "Règles sur l'utilisation des machines",
      content: `
        <h3>Consignes de sécurité</h3>
        
        <h4>Poids et haltères :</h4>
        <ul>
          <li>Ne pas laisser tomber les poids</li>
          <li>Replacer les poids après utilisation</li>
          <li>Utiliser les sangles de sécurité</li>
          <li>Ne pas surcharger les barres</li>
        </ul>
        
        <h4>Appareils cardio :</h4>
        <ul>
          <li>Limite de 30 minutes en période d'affluence</li>
          <li>Nettoyer l'appareil après utilisation</li>
          <li>Utiliser une serviette</li>
        </ul>
        
        <h4>Équipement spécialisé :</h4>
        <ul>
          <li>Demander une démonstration pour les machines complexes</li>
          <li>Respecter les poids maximum indiqués</li>
          <li>Signaler tout problème au personnel</li>
        </ul>
      `
    },
    nouveaux: {
      title: "Nouveaux clients",
      content: `
        <h3>Bienvenue aux nouveaux membres !</h3>
        
        <p>Pour votre première visite :</p>
        <ol>
          <li>Présentez-vous à l'accueil avec votre pièce d'identité</li>
          <li>Tour guidé obligatoire (30 minutes)</li>
          <li>Évaluation physique avec un coach</li>
          <li>Choix de votre programme d'entraînement</li>
        </ol>
        
        <h4>Offre spéciale nouveaux clients :</h4>
        <p>1 mois gratuit avec engagement annuel</p>
      `
    },
    nutrition: {
      title: "Alimentation et nutrition",
      content: `
        <h3>Conseils nutritionnels</h3>
        
        <p>Nos recommandations générales :</p>
        <ul>
          <li>Hydratation: 2L d'eau minimum par jour</li>
          <li>Protéines: 1.5g/kg de poids corporel</li>
          <li>Glucides complexes avant l'entraînement</li>
          <li>Protéines après l'entraînement</li>
        </ul>
        
        <h4>Services disponibles :</h4>
        <ul>
          <li>Bilan nutritionnel avec notre diététicienne</li>
          <li>Programmes alimentaires personnalisés</li>
          <li>Ateliers mensuels sur la nutrition sportive</li>
        </ul>
      `
    }
  };

  const service = services[serviceId];
  if (!service) return;

  detailsContainer.innerHTML = `
    <div class="service-detail-content">
      <h3>${service.title}</h3>
      <div>${service.content}</div>
      <div class="service-calendar">
        <h4>📅 Prendre rendez-vous pour consultation</h4>
        <div class="creneaux-dispo">
          ${['Lundi 10h', 'Mardi 14h', 'Jeudi 16h', 'Vendredi 11h']
            .map(creneau => `
              <div class="creneau" onclick="reserverVisite('${creneau}', '${service.title}')">
                ${creneau}
              </div>
            `).join('')}
        </div>
      </div>
    </div>
  `;
  
  detailsContainer.style.display = 'block';
  detailsContainer.scrollIntoView({ behavior: 'smooth' });
}



function effectuerRechercheDepuisService(nomService) {
  const nom = nomService.replace("Séance de ", "");
  afficherCategorie(nom);
}

// Gestion du mot de passe 
document.addEventListener("DOMContentLoaded", () => {
  const passwordInput = document.querySelector('#signupForm input[name="mot_de_passe"]');
  const strengthText = document.getElementById("passwordStrength");

  const rules = {
    length: document.getElementById("rule-length"),
    upper: document.getElementById("rule-upper"),
    lower: document.getElementById("rule-lower"),
    digit: document.getElementById("rule-digit"),
    special: document.getElementById("rule-special")
  };

  passwordInput.addEventListener("input", () => {
    const val = passwordInput.value;

    const validLength = val.length >= 8;
    const hasUpper = /[A-Z]/.test(val);
    const hasLower = /[a-z]/.test(val);
    const hasDigit = /\d/.test(val);
    const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(val);

    function updateRule(element, condition, text) {
      element.textContent = (condition ? "🟢" : "🔴") + " " + text;
      element.classList.remove("valid", "invalid");
      element.classList.add(condition ? "valid" : "invalid");
    }

    updateRule(rules.length, validLength, "Minimum 8 caractères");
    updateRule(rules.upper, hasUpper, "Une majuscule");
    updateRule(rules.lower, hasLower, "Une minuscule");
    updateRule(rules.digit, hasDigit, "Un chiffre");
    updateRule(rules.special, hasSpecial, "Un caractère spécial (!@#...)");

    const score = [validLength, hasUpper, hasLower, hasDigit, hasSpecial].filter(v => v).length;

    let label = "Très faible";
    if (score >= 4) label = "Fort 🔐";
    else if (score === 3) label = "Moyen 🧐";
    else if (score === 2) label = "Faible ⚠️";

    strengthText.textContent = "Force du mot de passe : " + label;
    strengthText.style.color = score >= 4 ? "green" : score === 3 ? "orange" : "red";
  });
});