<?php
session_start();
if (!isset($_SESSION["email"])) exit;

$conn = new mysqli("localhost", "root", "", "sportify");
if ($conn->connect_error) exit;

$sender = $_SESSION["email"];
$receiver = $_POST["receiver_email"] ?? null;
$contenu = trim($_POST["contenu"] ?? "");

if ($receiver && $contenu) {
    $stmt = $conn->prepare("INSERT INTO messages (sender_email, receiver_email, contenu) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $sender, $receiver, $contenu);
    $stmt->execute();
}