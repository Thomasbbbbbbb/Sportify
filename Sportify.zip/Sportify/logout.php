<?php
session_start();
session_destroy();
header("Location: index.html"); // Redirection vers la page d'accueil
exit;
