<?php
session_start();
$conn = new mysqli("localhost", "root", "", "sportify");
if ($conn->connect_error) {
    http_response_code(500);
    exit("Erreur BDD");
}

$clientEmail = $_SESSION["email"] ?? null;
$coachNom = $_POST["coach"] ?? '';
$jour = $_POST["jour"] ?? '';
$heure = $_POST["heure"] ?? '';

if (!$clientEmail || !$coachNom || !$jour || !$heure) {
    exit("❌ Connexion ou données manquantes.");
}

// on récupére l'ID du coach depuis comptes
$stmt = $conn->prepare("SELECT id FROM comptes WHERE nom = ? AND type = 'coach'");
$stmt->bind_param("s", $coachNom);
$stmt->execute();
$res = $stmt->get_result();
if (!($row = $res->fetch_assoc())) exit("❌ Coach introuvable");
$id_coach = $row["id"];

// on récupére l'ID du service depuis coachs
$stmt = $conn->prepare("SELECT id_service FROM coachs WHERE nom = ?");
$stmt->bind_param("s", $coachNom);
$stmt->execute();
$res = $stmt->get_result();
if (!($row = $res->fetch_assoc())) exit("❌ Service introuvable pour ce coach");
$id_service = $row["id_service"];


// on récupére l'ID du client
$stmt = $conn->prepare("SELECT id FROM comptes WHERE email = ?");
$stmt->bind_param("s", $clientEmail);
$stmt->execute();
$res = $stmt->get_result();
if (!($row = $res->fetch_assoc())) exit("❌ Client introuvable");
$id_client = $row["id"];

// on construit une date complete
$jourMap = ["Lundi"=>"Mon", "Mardi"=>"Tue", "Mercredi"=>"Wed", "Jeudi"=>"Thu", "Vendredi"=>"Fri"];
$refDate = date("Y-m-d", strtotime("next " . $jourMap[$jour]));
$datetime = "$refDate $heure:00";

// on vérifie si doublon existe
$check = $conn->prepare("SELECT * FROM rdv WHERE id_coach = ? AND date = ?");
$check->bind_param("is", $id_coach, $datetime);
$check->execute();
if ($check->get_result()->num_rows > 0) exit("❌ Créneau déjà réservé.");

// insertion finale
$stmt = $conn->prepare("INSERT INTO rdv (id_client, id_coach, date, lieu, id_service, statut) VALUES (?, ?, ?, 'Salle 1', ?, 'à venir')");
$stmt->bind_param("iisi", $id_client, $id_coach, $datetime, $id_service);
$stmt->execute();

// on récupére les détails du service pour le message
$stmt = $conn->prepare("SELECT s.nom, s.description FROM services s WHERE s.id = ?");
$stmt->bind_param("i", $id_service);
$stmt->execute();
$service = $stmt->get_result()->fetch_assoc();
$nom_service = $service['nom'] ?? "Service";
$desc_service = $service['description'] ?? "Pas de description";

// on formate message de confirmation
$system = "system@site.com";
$receiver = $clientEmail;
$heureFormatted = date("H:i", strtotime($heure));
$message = <<<MSG
✅ Votre rendez-vous a bien été enregistré :  

🧑‍🏫 Coach : $coachNom  
📅 Jour : $jour  
🕒 Heure : $heureFormatted  
🏷️ Service : $nom_service  
📝 Description : $desc_service  

📍 Lieu : Salle 1  

Merci pour votre confiance, à bientôt avec votre coach ! 🏋️‍♂️
MSG;

//on insére dans la table messages
$stmt = $conn->prepare("INSERT INTO messages (sender_email, receiver_email, contenu) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $system, $receiver, $message);
$stmt->execute();

header('Content-Type: application/json');
echo json_encode([
    'success' => true,
    'message' => "✅ RDV réservé avec $coachNom le $jour à $heure.",
    'jour' => $jour,
    'heure' => $heure
]);
exit();