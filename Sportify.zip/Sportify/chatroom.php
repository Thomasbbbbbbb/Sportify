<?php
session_start();
if (!isset($_SESSION["email"])) {
    header("Location: index.html");
    exit;
}

$conn = new mysqli("localhost", "root", "", "sportify");
if ($conn->connect_error) die("Erreur BDD");

// Nettoyage email connecté
$user_email = strtolower(trim($_SESSION["email"]));

// Identifier le type de compte
$typeQuery = $conn->prepare("SELECT type FROM comptes WHERE email=?");
$typeQuery->bind_param("s", $user_email);
$typeQuery->execute();
$typeResult = $typeQuery->get_result()->fetch_assoc();
$user_type = $typeResult["type"] ?? null;

// Déterminer avec qui chatter
$target_type = $user_type === "coach" ? "client" : "coach";
$dashboard_link = $user_type === "coach" ? "coach_dashboard.php" : "client_dashboard.php";

// Liste des contacts
$contacts = $conn->query("SELECT * FROM comptes WHERE type = '$target_type'");

// Email du contact sélectionné
$selectedEmail = $_GET["with"] ?? null;

// Charger messages
$messages = [];
if ($selectedEmail) {
    $clean_target = strtolower(trim($selectedEmail));
    $stmt = $conn->prepare("SELECT * FROM messages 
        WHERE (LOWER(TRIM(sender_email)) = ? AND LOWER(TRIM(receiver_email)) = ?)
           OR (LOWER(TRIM(sender_email)) = ? AND LOWER(TRIM(receiver_email)) = ?)
        ORDER BY date_envoi ASC");
    $stmt->bind_param("ssss", $user_email, $clean_target, $clean_target, $user_email);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) $messages[] = $row;
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Messagerie</title>
  <style>
    body { margin: 0; font-family: Arial; }
    .container { display: flex; height: 100vh; }
    .sidebar {
        width: 240px;
        background: #2f3640;
        color: white;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
    }
    .sidebar h2 {
        padding: 20px;
        margin: 0;
        background: #1e272e;
    }
    .contact {
        padding: 15px;
        cursor: pointer;
        border-bottom: 1px solid #3d3d3d;
    }
    .contact:hover {
        background-color: #485460;
    }
    .chat {
        flex-grow: 1;
        display: flex;
        flex-direction: column;
        background: #f1f2f6;
        position: relative;
    }
    .topbar {
        padding: 15px;
        background: #dfe6e9;
        border-bottom: 1px solid #ccc;
        font-weight: bold;
        display: flex;
        align-items: center;
    }
    .back-btn {
  font-size: 20px;
  margin-right: 10px;
  color: #ffffff;
  font-weight: bold;
  text-decoration: none;
}
.back-btn:hover {
  color: #74b9ff;
}

    .messages {
        flex: 1;
        padding: 20px;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
    }
    .message {
        margin: 10px 0;
        padding: 12px 18px;
        border-radius: 10px;
        max-width: 60%;
        animation: fadeIn 0.3s ease;
    }
    .sent { background: #d1f0ff; align-self: flex-end; }
    .received { background: #dfffd8; align-self: flex-start; }
    .form {
        display: flex;
        padding: 15px;
        background: #fff;
        border-top: 1px solid #ccc;
    }
    .form input {
        flex: 1;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }
    .form button {
        padding: 10px 20px;
        margin-left: 10px;
        background: #2ecc71;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body>
<div class="container">
  <div class="sidebar">
    <h2>
    <a href="<?= $dashboard_link ?>" class="back-btn" style="font-weight:bold; text-decoration:none;">←</a>
    <?= ucfirst($target_type) ?>s
    </h2>

    <?php while ($c = $contacts->fetch_assoc()): ?>
      <div class="contact" onclick="window.location='chatroom.php?with=<?= $c['email'] ?>'">
        <?= htmlspecialchars($c['nom']) ?><br><small><?= $c['email'] ?></small>
      </div>
    <?php endwhile; ?>
  </div>

  <div class="chat">
    <?php if ($selectedEmail): ?>
      <div class="topbar">
        Discussion avec <?= htmlspecialchars($selectedEmail) ?>
      </div>
      <div class="messages" id="messages">
        <?php foreach ($messages as $m): ?>
          <div class="message <?= strtolower(trim($m['sender_email'])) === $user_email ? 'sent' : 'received' ?>">
            <?= htmlspecialchars($m['contenu']) ?><br>
            <small><?= date("H:i", strtotime($m['date_envoi'])) ?></small>
          </div>
        <?php endforeach; ?>
      </div>
      <form class="form" id="msgForm">
        <input type="text" name="contenu" placeholder="Votre message..." required autocomplete="off">
        <input type="hidden" name="receiver_email" value="<?= $selectedEmail ?>">
        <button type="submit">Envoyer</button>
      </form>
    <?php else: ?>
      <div class="topbar">
        Messagerie
      </div>
      <div style="padding: 30px;">📨 Sélectionnez un contact pour démarrer une conversation.</div>
    <?php endif; ?>
  </div>
</div>

<script>
document.getElementById("msgForm")?.addEventListener("submit", function(e) {
  e.preventDefault();
  const formData = new FormData(this);
  fetch("envoyer_message.php", {
    method: "POST",
    body: formData
  }).then(() => location.reload());
});
</script>
</body>
</html>