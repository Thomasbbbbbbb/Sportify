<?php
session_start();
if (!isset($_SESSION["email"])) {
    header("Location: index.html");
    exit;
}

$conn = new mysqli("localhost", "root", "", "sportify");
if ($conn->connect_error) die("Erreur de connexion à la base de données");

$email = $_SESSION["email"];
$res = $conn->prepare("SELECT * FROM comptes JOIN coachs ON comptes.email = coachs.email WHERE comptes.email = ? AND comptes.type = 'coach'");
$res->bind_param("s", $email);
$res->execute();
$coach = $res->get_result()->fetch_assoc();

if (!$coach) {
    echo "Accès interdit.";
    exit;
}

$conn->query("UPDATE rdv SET statut='passé' WHERE date < NOW() AND statut='à venir'");
$rdv = $conn->query("SELECT r.*, cl.nom AS client_nom, cl.email AS client_email, cl.adresse, cl.carte_etudiante 
                     FROM rdv r
                     JOIN comptes cl ON r.id_client = cl.id
                     WHERE r.id_coach = {$coach['id']}
                     ORDER BY r.date DESC")->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Dashboard Coach</title>
  <style>
    body {
      margin: 0;
      background: #ecf0f1;
      font-family: 'Segoe UI', sans-serif;
      color: #2c3e50;
    }
    header {
      background: #2c3e50;
      color: white;
      padding: 20px;
      font-size: 24px;
      text-align: center;
    }
    .main {
      display: flex;
      justify-content: center;
      align-items: flex-start;
      gap: 30px;
      padding: 30px;
      animation: fadeIn 0.4s ease-in-out;
    }
    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
    .left, .right {
      background: #ffffff;
      border-radius: 10px;
      box-shadow: 0 8px 20px rgba(0,0,0,0.1);
      padding: 25px;
    }
    .left {
      flex: 1;
      max-width: 350px;
    }
    .right {
      flex: 2;
      max-width: 700px;
    }
    .button {
      background: #3498db;
      color: white;
      padding: 10px 18px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s ease;
      text-decoration: none;
      display: inline-block;
      margin-right: 10px;
    }
    .button:hover {
      background: #2980b9;
    }
    .logout-button {
      background: #e74c3c;
    }
    .logout-button:hover {
      background: #c0392b;
    }
    .info-block {
      background: #f9f9f9;
      border-left: 5px solid #00cec9;
      padding: 15px 20px;
      margin-bottom: 15px;
      border-radius: 6px;
    }
    .info-block pre {
      white-space: pre-wrap;
      word-wrap: break-word;
    }
    img {
      max-width: 100%;
      border-radius: 8px;
    }
    .timeline-title {
      font-size: 20px;
      margin-bottom: 20px;
    }
    .rdv-item {
      margin-bottom: 15px;
      padding: 15px;
      border-left: 5px solid #ccc;
      background: #fff;
      border-radius: 6px;
    }
    .rdv-avenir { border-color: #2ecc71; }
    .rdv-annule { border-color: #e74c3c; }
    .rdv-passe { border-color: #bdc3c7; }
  </style>
</head>
<body>
  <header>🎯 Tableau de bord Coach</header>
  <div class="main">
    <div class="left">
      <h2>👤 Informations Coach</h2>
      <div class="info-block"><strong>Nom :</strong> <?= htmlspecialchars($coach["nom"]) ?></div>
      <div class="info-block"><strong>Email :</strong> <?= htmlspecialchars($coach["email"]) ?></div>
      <div class="info-block"><strong>Spécialité :</strong> <?= htmlspecialchars($coach["specialite"]) ?></div>
      <div class="info-block"><strong>Disponibilité :</strong><br><pre><?= htmlspecialchars($coach["disponibilite"]) ?></pre></div>
      <div class="info-block"><strong>CV :</strong> <?= $coach["cv"] ? "<a href='voir_cv.php?file=" . urlencode(basename($coach["cv"])) . "' target='_blank'>📄 Voir CV</a>" : "Non renseigné" ?></div>
      <div class="info-block"><strong>Vidéo :</strong> <?= $coach["video"] ? "<a href='{$coach["video"]}' target='_blank'>▶️ Voir vidéo</a>" : "Non renseignée" ?></div>
      <div class="info-block"><strong>Photo :</strong><br> <?= $coach["photo"] ? "<img src='" . htmlspecialchars($coach["photo"]) . "'>" : "Non renseignée" ?></div>
      <br>
      <a href="chatroom.php" class="button">💬 Messagerie</a>
      <button class="button logout-button" id="logoutBtn">🚪 Se déconnecter</button>
    </div>
    <div class="right">
      <h2 class="timeline-title">📅 Historique des Rendez-vous</h2>
      <?php foreach ($rdv as $r): ?>
        <?php
          $class = 'rdv-item';
          $class .= $r['statut'] === 'annulé' ? ' rdv-annule' : ($r['statut'] === 'passé' ? ' rdv-passe' : ' rdv-avenir');
        ?>
        <div class="<?= $class ?>">
          <strong><?= date('d/m/Y H:i', strtotime($r['date'])) ?></strong> — <strong><?= strtoupper($r['statut']) ?></strong><br>
          Service : <?= htmlspecialchars($r['id_service']) ?><br>
          Lieu : <?= htmlspecialchars($r['lieu']) ?><br><br>
          <strong>Client :</strong> <?= htmlspecialchars($r['client_nom']) ?> (<a href="mailto:<?= $r['client_email'] ?>"><?= $r['client_email'] ?></a>)<br>
          Adresse : <?= $r['adresse'] ?: 'Non renseignée' ?><br>
          Carte étudiante : <?= $r['carte_etudiante'] ?: 'Non renseignée' ?>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
  <script>
  document.getElementById("logoutBtn")?.addEventListener("click", function (e) {
    e.preventDefault();
    const btn = this;
    const text = "Déconnexion...";
    btn.disabled = true;
    btn.innerText = "";
    let i = 0;
    const anim = setInterval(() => {
      btn.innerText += text[i++];
      if (i === text.length) {
        clearInterval(anim);
        setTimeout(() => {
          window.location.href = "logout.php";
        }, 500);
      }
    }, 50);
  });
  </script>
</body>
</html>