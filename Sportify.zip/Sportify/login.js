document.addEventListener("DOMContentLoaded", () => {
  // === Connexion ===
  const modal = document.getElementById("loginModal");
  const closeBtn = document.getElementById("closeLoginModal");
  const openBtn = document.getElementById("btn-compte");
  const form = document.getElementById("loginForm");
  const loginBtn = document.getElementById("loginBtn");
  const feedback = document.getElementById("loginFeedback");

  openBtn.addEventListener("click", (e) => {
    e.preventDefault();
    modal.classList.add("active");
    feedback.innerText = "";
    loginBtn.disabled = false;
    loginBtn.innerText = "Se connecter";
  });

  closeBtn.addEventListener("click", () => {
    modal.classList.remove("active");
  });

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const formData = new FormData(form);
    loginBtn.disabled = true;
    loginBtn.innerText = "";
    feedback.innerText = "";

    const animText = "Connexion...";
    let i = 0;
    const interval = setInterval(() => {
      loginBtn.innerText += animText[i++];
      if (i === animText.length) {
        clearInterval(interval);
        setTimeout(() => {
          fetch("login.php", {
            method: "POST",
            body: formData,
          })
            .then(res => res.json())
            .then(data => {
              if (data.success) {
                window.location.href = data.redirect;
              } else {
                feedback.innerText = data.message;
                loginBtn.disabled = false;
                loginBtn.innerText = "Se connecter";
              }
            })
            .catch(() => {
              feedback.innerText = "Erreur de connexion au serveur.";
              loginBtn.disabled = false;
              loginBtn.innerText = "Se connecter";
            });
        }, 300);
      }
    }, 50);
  });

  // === Création de compte ===
  const signupModal = document.getElementById("signupModal");
  const openSignupBtn = document.getElementById("createAccountBtn");
  const closeSignupBtn = document.getElementById("closeSignupModal");
  const signupForm = document.getElementById("signupForm");
  const signupFeedback = document.getElementById("signupFeedback");
  const signupBtn = document.getElementById("signupBtn");

  if (openSignupBtn) {
    openSignupBtn.addEventListener("click", () => {
      modal.classList.remove("active");
      signupModal.classList.add("active");
      signupFeedback.innerText = "";
    });
  }

  if (closeSignupBtn) {
    closeSignupBtn.addEventListener("click", () => {
      signupModal.classList.remove("active");
    });
  }

  if (signupForm) {
    signupForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const formData = new FormData(signupForm);
      signupBtn.disabled = true;
      signupBtn.innerText = "Création...";
      signupFeedback.innerText = "";

      fetch("signup.php", {
        method: "POST",
        body: formData,
      })
        .then(res => res.json())
        .then(data => {
          if (data.success) {
            signupFeedback.style.color = "green";
            signupFeedback.innerText = "Compte créé avec succès. Vous pouvez vous connecter.";
            setTimeout(() => {
              signupModal.classList.remove("active");
              modal.classList.add("active");
            }, 2000);
          } else {
            signupFeedback.style.color = "red";
            signupFeedback.innerText = data.message;
          }
          signupBtn.disabled = false;
          signupBtn.innerText = "Créer le compte";
        })
        .catch(() => {
          signupFeedback.innerText = "Erreur serveur.";
          signupBtn.disabled = false;
          signupBtn.innerText = "Créer le compte";
        });
    });
  }
});
