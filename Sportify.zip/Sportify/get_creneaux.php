<?php
header("Content-Type: application/json");

$jours = ["Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi"];
$heures = [];
for ($h = 9; $h <= 22; $h++) {
    $heures[] = str_pad($h, 2, "0", STR_PAD_LEFT) . ":00";
    $heures[] = str_pad($h, 2, "0", STR_PAD_LEFT) . ":20";
    $heures[] = str_pad($h, 2, "0", STR_PAD_LEFT) . ":40";
}

$conn = new mysqli("localhost", "root", "", "sportify");
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["error" => "Connexion à la BDD échouée"]);
    exit;
}

$coachNom = $_GET["coach"] ?? "";
$coachNom = trim($coachNom);

// on récupére les disponibilités du coach
$stmt = $conn->prepare("SELECT disponibilite FROM coachs WHERE nom = ?");
$stmt->bind_param("s", $coachNom);
$stmt->execute();
$result = $stmt->get_result();

if ($row = $result->fetch_assoc()) {
    $dispos = $row["disponibilite"];
    $cal = [];

    // on récupére les rendez-vous déjà pris
    $stmtRdv = $conn->prepare("
        SELECT DATE_FORMAT(date, '%H:%i') as heure, 
               CASE DAYOFWEEK(date)
                   WHEN 2 THEN 'Lundi'
                   WHEN 3 THEN 'Mardi'
                   WHEN 4 THEN 'Mercredi'
                   WHEN 5 THEN 'Jeudi'
                   WHEN 6 THEN 'Vendredi'
               END as jour
        FROM rdv 
        WHERE id_coach = (SELECT id FROM comptes WHERE nom = ? AND type = 'coach')
        AND statut = 'à venir'
    ");
    $stmtRdv->bind_param("s", $coachNom);
    $stmtRdv->execute();
    $rdvs = $stmtRdv->get_result()->fetch_all(MYSQLI_ASSOC);

    // on initialise le calendrier avec toutes les cases indisponibles par défaut
    foreach ($jours as $jour) {
        foreach ($heures as $h) {
            $cal[$jour][$h] = "indisponible";
        }
    }

    // on marque les disponibilités du coach
    foreach ($jours as $jour) {
        if (preg_match("/$jour\s*:\s*([^\r\n]*)/i", $dispos, $match)) {
            $plages = explode(",", $match[1]);

            foreach ($plages as $plage) {
                if (stripos($plage, "absent") !== false || stripos($plage, "sur rendez-vous") !== false) continue;

                if (preg_match("/(\d{1,2})h\s*-\s*(\d{1,2})h/", $plage, $heuresMatch)) {
                    $hStart = intval($heuresMatch[1]);
                    $hEnd = intval($heuresMatch[2]);

                    foreach ($heures as $slot) {
                        $heureSlot = intval(substr($slot, 0, 2));
                        if ($heureSlot >= $hStart && $heureSlot < $hEnd) {
                            $cal[$jour][$slot] = "disponible";
                        }
                    }
                }
            }
        }
    }

    // on marque les rendez-vous déjà pris comme "pris"
    foreach ($rdvs as $rdv) {
        if (isset($cal[$rdv['jour']][$rdv['heure']])) {
            $cal[$rdv['jour']][$rdv['heure']] = "pris";
        }
    }

    echo json_encode($cal, JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(["error" => "Coach introuvable"]);
}
?>