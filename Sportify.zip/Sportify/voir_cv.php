<?php
if (!isset($_GET["file"])) {
    echo "❌ Aucun fichier CV spécifié.";
    exit;
}

$filename = basename($_GET["file"]); // on securise pour éviter les chemins
$filepath = __DIR__ . "/cv/" . $filename;

if (!file_exists($filepath)) {
    echo "❌ Fichier introuvable.";
    exit;
}

// on charge le fichier XML
$xml = simplexml_load_file($filepath);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>CV de <?= htmlspecialchars($xml->nom) ?></title>
    <style>
        body { font-family: Arial; margin: 40px; }
        h1 { color: #004080; }
        ul { list-style: square; }
    </style>
</head>
<body>
    <h1>📄 CV de <?= htmlspecialchars($xml->nom) ?></h1>
    <p><strong>Spécialité :</strong> <?= htmlspecialchars($xml->specialite) ?></p>

    <h2>🎓 Formations</h2>
    <ul>
        <?php foreach ($xml->formations->formation as $formation): ?>
            <li><?= htmlspecialchars($formation) ?></li>
        <?php endforeach; ?>
    </ul>

    <h2>💼 Expériences</h2>
    <ul>
        <?php foreach ($xml->experiences->experience as $experience): ?>
            <li><?= htmlspecialchars($experience) ?></li>
        <?php endforeach; ?>
    </ul>

    <br><a href="index.html">⬅️ Retour</a>
</body>
</html>
