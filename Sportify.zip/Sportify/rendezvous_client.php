<?php
session_start();
if (!isset($_SESSION["email"])) {
    http_response_code(403);
    exit("⚠️ Connexion requise.");
}

$conn = new mysqli("localhost", "root", "", "sportify");
if ($conn->connect_error) exit("❌ Connexion BDD");

$email = $_SESSION["email"];
$client = $conn->query("SELECT id FROM comptes WHERE email='$email' AND type='client'")->fetch_assoc();
if (!$client) exit("⚠️ Client non trouvé.");

$idClient = $client['id'];

$rdv = $conn->query("SELECT r.id, r.date, r.statut, r.lieu, s.nom AS service, c.nom AS coach,
  (SELECT statut FROM paiements WHERE id_rdv = r.id AND id_client = $idClient LIMIT 1) AS paiement_statut
  FROM rdv r
  JOIN services s ON s.id = r.id_service
  JOIN comptes c ON c.id = r.id_coach
  WHERE r.id_client = $idClient
  ORDER BY r.date DESC");

echo <<<HTML
<style>
.timeline-rdv-container {
  max-width: 950px;
  margin: 40px auto;
  animation: fadeIn 0.5s ease-in;
}
.timeline-rdv-title {
  text-align: center;
  color: #2c3e50;
  font-size: 28px;
  margin-bottom: 30px;
}
#filterStatus {
  padding: 8px;
  margin-bottom: 20px;
  border-radius: 6px;
  border: 1px solid #ccc;
  font-size: 1rem;
}
.timeline-scroll {
  max-height: 900px;
  overflow-y: auto;
  padding-right: 12px;
  scrollbar-width: thin;
  scrollbar-color: #ccc #f0f0f0;
}
.timeline-scroll::-webkit-scrollbar {
  width: 8px;
}
.timeline-scroll::-webkit-scrollbar-thumb {
  background-color: #aaa;
  border-radius: 10px;
}
.timeline-scroll::-webkit-scrollbar-track {
  background-color: #f5f5f5;
  border-radius: 10px;
}
.rdv-card {
  background: #fff;
  padding: 20px;
  margin-bottom: 20px;
  border-radius: 10px;
  box-shadow: 0 4px 15px rgba(0,0,0,0.08);
  position: relative;
  display: flex;
  gap: 15px;
  animation: fadeInCard 0.4s ease;
  transition: opacity 0.5s ease, transform 0.5s ease;
}
.rdv-card.fade-out {
  opacity: 0;
  transform: translateX(-20px);
}
.rdv-left-bar {
  width: 6px;
  border-radius: 10px 0 0 10px;
}
.rdv-content {
  flex: 1;
}
.rdv-date {
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 10px;
}
.badge {
  display: inline-block;
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 14px;
  color: white;
  font-weight: bold;
  margin-right: 10px;
}
.badge.vert { background-color: #2ecc71; }
.badge.rouge { background-color: #e74c3c; }
.badge.gris { background-color: #bdc3c7; }
.bar.vert { background-color: #2ecc71; }
.bar.rouge { background-color: #e74c3c; }
.bar.gris { background-color: #bdc3c7; }

.btn-annuler {
  margin-top: 12px;
  padding: 8px 14px;
  background-color: #e74c3c;
  color: white;
  border: none;
  border-radius: 6px;
  cursor: pointer;
}
.btn-annuler:hover {
  background-color: #c0392b;
}
@keyframes fadeInCard {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}
</style>

<div class="timeline-rdv-container">
  <h2 class="timeline-rdv-title">📅 Mes rendez-vous</h2>
    <div class="timeline-scroll" id="rdvList">
HTML;

$i = 0;
while ($r = $rdv->fetch_assoc()) {
    $idRdv = $r["id"];
    $date = date("d/m/Y H:i", strtotime($r["date"]));
    $statut = $r["statut"];
    $statutClasse = ($statut === "à venir") ? "vert" : (($statut === "annulé") ? "rouge" : "gris");
    $badge = ucfirst($statut);
    $paiement = $r["paiement_statut"] === "validé" ? "✅ Payé" : "❌ Non payé";

    echo "<div class='rdv-card' data-statut='$statut' id='rdv-$idRdv'>";
    echo "<div class='rdv-left-bar bar $statutClasse'></div>";
    echo "<div class='rdv-content'>";
    echo "<div class='rdv-date'>$date — Coach : <strong>{$r['coach']}</strong></div>";
    echo "<div><span class='badge $statutClasse'>$badge</span></div>";
    echo "<div>🏋️ Service : <strong>{$r['service']}</strong><br>📍 Lieu : {$r['lieu']}<br>💳 Paiement : $paiement</div>";

    if ($statut === "à venir") {
        echo "<form method='post' action='client_dashboard.php' onsubmit='return annulerRdvAnim(event, $idRdv)'>";
        echo "<input type='hidden' name='annuler_rdv' value='$idRdv'>";
        echo "<button type='submit' class='btn-annuler'>🗑️ Annuler le RDV</button>";
        echo "</form>";
    }

    echo "</div></div>";
    $i++;
}

if ($i === 0) {
    echo "<p style='text-align:center; margin-top:30px;'>Aucun rendez-vous pour le moment.</p>";
}

echo "</div></div>";

echo <<<JS
<script>
function annulerRdvAnim(e, id) {
  e.preventDefault();
  const card = document.getElementById('rdv-' + id);
  card.classList.add('fade-out');
  setTimeout(() => {
    e.target.submit();
  }, 500);
  return false;
}
</script>
JS;
?>