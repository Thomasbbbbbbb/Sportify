<?php
$conn = new mysqli("localhost", "root", "", "sportify");
if ($conn->connect_error) {
    http_response_code(500);
    exit("Erreur BDD");
}

$sql = "
  SELECT s.*, GROUP_CONCAT(ss.id_service) AS services_ids
  FROM salle_sport s
  LEFT JOIN salle_service ss ON s.id = ss.id_salle
  GROUP BY s.id
";
$res = $conn->query($sql);

$salles = [];
while ($row = $res->fetch_assoc()) {
    $serviceIds = explode(",", $row['services_ids']);
    $services = [];

    if (!empty($row['services_ids'])) {
        $in = implode(",", array_map('intval', $serviceIds));
        $serviceRes = $conn->query("SELECT * FROM services WHERE id IN ($in)");

        while ($srv = $serviceRes->fetch_assoc()) {
            $services[] = $srv;
        }
    }

    $row['services'] = $services;
    unset($row['services_ids']);
    $salles[] = $row;
}

header("Content-Type: application/json");
echo json_encode($salles);
?>